package Test;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;

import parque.data.ParqueAtracciones;
import parque.enumeraciones.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.usuarios.Usuario.TipoUsuario;
import parque.ventas.GestorVentas;
import parque.tiquetes.*;

import java.io.File;
import java.time.LocalDate;

class EmpleadoTest {

    private Empleado cajero;
    private Usuario cliente;
    private ParqueAtracciones parque;

    @BeforeEach	
    void setUp() {
        cajero = new OperadorAtraccionRiesgoMedio("ope", "clave", "María", 28);
        cliente = new Usuario("Pedro", "pedro1", "pass", false, TipoUsuario.CLIENTE) {};
      
        Labor labor = new Labor(
        	    Dia.LUNES,                  // Día de la semana
        	    Turno.APERTURA,            // Turno
        	    Actividad.CAJERO,          // Actividad
        	    new LugarDeServicios("Baño 1", new Ubicacion("Zona Jurásica", 3, "Calle de los Dinosaurios #45"),TipoLugar.TAQUILLA), // Lugar de trabajo
        	    LocalDate.now()            // Fecha
        	);
        cajero.getLabores().add(labor);
        
        parque = new ParqueAtracciones("Parque Virtual");
        new GestorVentas("ventas-usuario-test.txt", parque);
    }

    @AfterEach
    void tearDown() {
        File archivo = new File("ventas-usuario-test.txt");
        if (archivo.exists()) archivo.delete();
    }
    
    @Test
    void testVenderTiqueteRegularComoCajero() {
        Tiquete t = cajero.venderTiqueteRegular(cliente, Exclusividad.BASICO, Precios.BASICO);
        assertNotNull(t);
        assertTrue(cliente.getTiquetesRegulares().contains(t));
    }

    @Test
    void testVenderTiqueteRegularSinLabor() {
        cajero.getLabores().clear();
        assertThrows(IllegalStateException.class, () -> {
            cajero.venderTiqueteRegular(cliente, Exclusividad.BASICO, Precios.BASICO);
        });
    }
}