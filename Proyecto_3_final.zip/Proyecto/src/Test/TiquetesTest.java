package Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Collections;
import java.util.Date;

import parque.atraccion.*;
import parque.enumeraciones.*;
import parque.modelo.*;
import parque.tiquetes.*;


class TiquetesTest {

    private Atraccion atraccion;

    @BeforeEach
    void setUp() {
        Ubicacion ubicacion = new Ubicacion("Zona Selvática", 2, "Camino de la Aventura #11");
        RangoFuncionamiento rango = new RangoFuncionamiento(
            LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31));

        atraccion = new AtraccionMecanica(
            "Selva Extrema",
            ubicacion,
            20,
            2,
            Exclusividad.FAMILIAR,
            false,
            rango,
            Collections.emptyList(),
            100,
            200,
            30,
            120,
            false,
            Collections.emptyList(),
            Riesgo.MEDIO
        );
    }

    @Test
    void testTiqueteIndividual() {
        TiqueteIndividual t = new TiqueteIndividual(10000, true, atraccion);
        assertEquals(10000, t.precio);
        assertFalse(t.isUsed());
        assertEquals(atraccion, t.getAtraccion());
        assertTrue(t.toRegistro().contains("INDIVIDUAL"));
    }

    @Test
    void testFastPass() {
        Date fecha = new Date();
        FastPass fp = new FastPass(15000, true, fecha);
        assertEquals(15000, fp.precio);
        assertFalse(fp.isUsed());
        assertEquals(fecha, fp.getFecha());
        assertTrue(fp.toRegistro().contains("FASTPASS"));
    }

    @Test
    void testTiqueteRegular() {
        TiqueteRegular t = new TiqueteRegular(20000, true, Exclusividad.DIAMANTE);
        assertEquals(Exclusividad.DIAMANTE, t.getCategoria());
        assertTrue(t.toRegistro().contains("INDIVIDUAL"));
    }

    @Test
    void testTiqueteTemporada() {
        RangoFuncionamiento rango = new RangoFuncionamiento(
            LocalDate.of(2025, 7, 1),
            LocalDate.of(2025, 7, 31)
        );
        TiqueteTemporada t = new TiqueteTemporada(25000, false, Exclusividad.ORO, rango);
        assertEquals(Exclusividad.ORO, t.getCategoria());
        assertEquals(rango, t.getRangoFechas());
        assertTrue(t.toRegistro().contains("TEMPORADA"));
    }
}
