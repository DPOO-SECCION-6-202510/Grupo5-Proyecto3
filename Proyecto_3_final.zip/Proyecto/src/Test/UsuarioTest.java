package Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import parque.usuarios.*;
import parque.usuarios.Usuario.TipoUsuario;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.atraccion.*;
import parque.ventas.*;
import parque.data.*;
import parque.modelo.*;

import java.time.LocalDate;
import java.util.*;
import java.io.File;

class UsuarioTest {

    private Usuario cliente;
    private ParqueAtracciones parque;

    @BeforeEach
    void setUp() {
        cliente = new Usuario("Carlos", "carlos123", "clave", false, TipoUsuario.CLIENTE) {};

        parque = new ParqueAtracciones("Parque Virtual");

        Ubicacion ubicacion = new Ubicacion("Zona Espacial", 7, "Pasaje Galáctico #7");
        RangoFuncionamiento rango = new RangoFuncionamiento(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31));

        AtraccionMecanica atraccion = new AtraccionMecanica(
                "Montaña Lunar",
                ubicacion,
                30,
                3,
                Exclusividad.ORO,
                false,
                rango,
                Collections.singletonList(RestriccionClima.TORMENTA),
                120,
                200,
                35,
                110,
                true,
                Collections.singletonList(RestriccionSalud.VERTIGO),
                Riesgo.ALTO
        );

        parque.getAtracciones().add(atraccion);

        new GestorVentas("ventas-usuario-test.txt", parque);
    }

    @AfterEach
    void tearDown() {
        File archivo = new File("ventas-usuario-test.txt");
        if (archivo.exists()) archivo.delete();
    }

    @Test
    void testComprarTiqueteRegularEnLinea() {
        Tiquete t = cliente.comprarTiqueteRegularEnLinea(Exclusividad.ORO, Precios.ORO);
        assertNotNull(t);
        assertTrue(cliente.getTiquetesRegulares().contains(t));
    }

    @Test
    void testComprarTiqueteIndividualEnLinea() {
        Tiquete t = cliente.comprarTiqueteIndividualEnLinea("Montaña Lunar", Precios.INDIVIDUAL.getPrecio());
        assertNotNull(t);
        assertTrue(cliente.getTiquetesIndividuales().contains(t));
    }

    @Test
    void testComprarTiqueteTemporadaEnLinea() {
        RangoFuncionamiento rango = new RangoFuncionamiento(
                LocalDate.of(2025, 6, 1),
                LocalDate.of(2025, 6, 30)
        );
        Tiquete t = cliente.comprarTiqueteTemporadaEnLinea(Exclusividad.FAMILIAR, rango, Precios.FAMILIAR);
        assertNotNull(t);
        assertTrue(cliente.getTiquetesRegulares().contains(t)); // porque hereda de TiqueteRegular
    }

    @Test
    void testComprarFastPassEnLinea() {
        java.sql.Date fecha = new java.sql.Date(new Date().getTime());
        Tiquete t = cliente.comprarFastPassEnLinea(fecha, Precios.FASTPASS.getPrecio());
        assertNotNull(t);
        assertTrue(cliente.getTiquetesFastPass().contains(t));
    }

}
