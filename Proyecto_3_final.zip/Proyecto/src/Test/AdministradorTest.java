package Test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import parque.enumeraciones.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;

import java.time.LocalDate;

class AdministradorTest {

    private Administrador admin;
    private ParqueAtracciones parque;

    @BeforeEach
    void setUp() {
        parque = new ParqueAtracciones("Parque Fantasía");
        admin = new Administrador("Admin", "admin1", "pass", parque);
    }

    @Test
    void testAgregarYEliminarEmpleado() {
        Empleado e = new OperadorAtraccionRiesgoMedio("ope", "123", "Carlos", 30);
        admin.agregarEmpleado(e);
        assertTrue(parque.getEmpleados().contains(e));
        admin.eliminarEmpleado(e);
        assertFalse(parque.getEmpleados().contains(e));
    }

    @Test
    void testAsignarYQuitarLabor() {
        Empleado e = new OperadorAtraccionRiesgoMedio("ope", "123", "Carlos", 30);
        Labor labor = new Labor(
        	    Dia.LUNES,                  // Día de la semana
        	    Turno.APERTURA,            // Turno
        	    Actividad.CAJERO,          // Actividad
        	    new LugarDeServicios("Baño 1", new Ubicacion("Zona Jurásica", 3, "Calle de los Dinosaurios #45"),TipoLugar.TAQUILLA), // Lugar de trabajo
        	    LocalDate.now()            // Fecha
        	);
        admin.asignarLabor(e, labor);
        assertTrue(e.getLabores().contains(labor));
        admin.quitarLabor(e, labor);
        assertFalse(e.getLabores().contains(labor));
    }
}