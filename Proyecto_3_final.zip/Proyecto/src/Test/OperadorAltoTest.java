package Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import parque.ventas.*;
import parque.atraccion.*;
import parque.enumeraciones.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.tiquetes.*;

class OperadorAltoTest {

    private OperadorAtraccionRiesgoAlto operador;
    private AtraccionMecanica atraccion;
    private ValidadorTiquetes validador;

    @BeforeEach
    void setUp() {
        // Ubicación ficticia
        Ubicacion ubicacion = new Ubicacion("Zona Apocalíptica", 5, "Pasaje Extremo #9");

        // Rango de fechas de operación
        LocalDate inicio = LocalDate.of(2025, 6, 1);
        LocalDate fin = LocalDate.of(2025, 12, 31);
        RangoFuncionamiento rango = new RangoFuncionamiento(inicio, fin);

        // Restricciones
        List<RestriccionClima> clima = Arrays.asList(RestriccionClima.TORMENTA);
        List<RestriccionSalud> salud = Arrays.asList(RestriccionSalud.PROBLEMAS_CARDIACOS);

        // Crear atracción
        atraccion = new AtraccionMecanica(
            "Torre del Miedo",
            ubicacion,
            30,
            2,
            Exclusividad.ORO,
            false,
            rango,
            clima,
            140,
            200,
            40,
            120,
            true,
            salud,
            Riesgo.ALTO
        );

        operador = new OperadorAtraccionRiesgoAlto("al1", "123", "Laura", 35, atraccion);
        validador = new ValidadorTiquetes("log-operador.txt");
    }

    @Test
    void testValidarTiqueteCorrecto() {
        Tiquete t = new TiqueteIndividual(8000, true, atraccion);
        String resultado = operador.validarYRegistrarTiquete(t, LocalDate.now(), validador);
        assertTrue(resultado.contains("Acceso concedido"));
        assertTrue(t.isUsed());
    }
}


