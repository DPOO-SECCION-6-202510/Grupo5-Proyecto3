package Test;
import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import parque.ventas.*;
import parque.atraccion.*;
import parque.enumeraciones.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.usuarios.Usuario.TipoUsuario;
import parque.tiquetes.*;
import parque.data.*;

class GestorVentasTest {

    private Usuario cliente;
    private Usuario empleado;
    private ParqueAtracciones parque;
    private AtraccionMecanica atraccionMecanica;

    @BeforeEach
    void setUp() {
        cliente = new Usuario("Juan", "juan123", "pass", false, TipoUsuario.CLIENTE) {};
        empleado = new Usuario("Ana", "ana123", "clave", true, TipoUsuario.EMPLEADO) {};

        // Crear ubicación ficticia
        Ubicacion ubicacion = new Ubicacion("Zona Jurásica", 3, "Calle de los Dinosaurios #45");

        // Crear rango de funcionamiento
        LocalDate inicio = LocalDate.of(2025, 6, 1);
        LocalDate fin = LocalDate.of(2025, 12, 31);
        RangoFuncionamiento rango = new RangoFuncionamiento(inicio, fin);

        // Crear restricciones
        List<RestriccionClima> restriccionesClima = Arrays.asList(RestriccionClima.TORMENTA);
        List<RestriccionSalud> restriccionesSalud = Arrays.asList(RestriccionSalud.VERTIGO);

        // Crear atracción mecánica
        atraccionMecanica = new AtraccionMecanica(
            "Montaña Rusa",
            ubicacion,
            20,
            2,
            Exclusividad.FAMILIAR,
            false,
            rango,
            restriccionesClima,
            120,
            200,
            30,
            120,
            true,
            restriccionesSalud,
            Riesgo.ALTO
        );

        parque = new ParqueAtracciones("Parque de Pruebas");
        parque.getAtracciones().add(atraccionMecanica);

        new GestorVentas("ventas-test.txt", parque);
    }

    @Test
    void testVenderTiqueteRegular() {
        Tiquete t = GestorVentas.venderTiqueteRegular(cliente, Exclusividad.FAMILIAR, Precios.FAMILIAR);
        assertNotNull(t);
        assertTrue(cliente.getTiquetesRegulares().contains(t));
    }

    @Test
    void testVenderTiqueteIndividual_AtraccionNoExiste() {
        assertThrows(IllegalArgumentException.class, () -> {
            GestorVentas.venderTiqueteIndividual(cliente, "NoExiste", 5000);
        });
    }

    @Test
    void testVenderTiqueteIndividual_ConDescuento() {
        double precio = 10000;
        Tiquete t = GestorVentas.venderTiqueteIndividual(empleado, "Montaña Rusa", precio);
        double esperado = precio * 0.8;
        assertEquals(esperado, t.precio, 0.1);
        assertTrue(empleado.getTiquetesIndividuales().contains(t));
    }

    @Test
    void testVenderFastPass() {
        Date fecha = new Date();
        FastPass fp = GestorVentas.venderFastPass(cliente, fecha, Precios.FASTPASS.getPrecio());
        assertNotNull(fp);
        assertTrue(cliente.getTiquetesFastPass().contains(fp));
    }

    @Test
    void testVenderTiqueteTemporada() {
        LocalDate inicio = LocalDate.of(2025, 7, 1);
        LocalDate fin = LocalDate.of(2025, 7, 31);
        RangoFuncionamiento rango = new RangoFuncionamiento(inicio, fin);
        Tiquete t = GestorVentas.venderTiqueteTemporada(cliente, Exclusividad.BASICO, rango, Precios.BASICO);
        assertNotNull(t);
        assertTrue(cliente.getTiquetesRegulares().contains(t));
    }

    @Test
    void testInvalidarTiquete() {
        Tiquete t = GestorVentas.venderTiqueteRegular(cliente, Exclusividad.BASICO, Precios.BASICO);
        assertFalse(t.isUsed());
        GestorVentas.invalidarTiquete(t);
        assertTrue(t.isUsed());
    }
}


