package Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.time.LocalDate;
import java.util.Collections;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import parque.ventas.*;
import parque.atraccion.*;
import parque.enumeraciones.*;
import parque.modelo.*;
import parque.tiquetes.*;

class ValidadorTiquetesTest {

    private ValidadorTiquetes validador;
    private AtraccionMecanica atraccion;
    private File log;

    @BeforeEach
    void setUp() {
        log = new File("log-validador-test.txt");
        validador = new ValidadorTiquetes(log.getPath());

        // Crear atracción
        Ubicacion ubicacion = new Ubicacion("Zona Fantasía", 1, "Camino de los Sueños #1");
        RangoFuncionamiento rango = new RangoFuncionamiento(LocalDate.of(2025, 1, 1), LocalDate.of(2025, 12, 31));
        atraccion = new AtraccionMecanica(
                "Rueda Panorámica",
                ubicacion,
                15,
                2,
                Exclusividad.BASICO,
                false,
                rango,
                Collections.emptyList(),
                100,
                200,
                40,
                120,
                false,
                Collections.emptyList(),
                Riesgo.MEDIO
        );
    }

    @AfterEach
    void tearDown() {
        if (log.exists()) {
            log.delete();
        }
    }

    @Test
    void testEsValidoPara_TiqueteIndividualCorrecto() {
        Tiquete t = new TiqueteIndividual(5000, true, atraccion);
        assertTrue(validador.esValidoPara(t, atraccion, LocalDate.now()));
    }

    @Test
    void testEsValidoPara_TiqueteTemporadaDentroDeRango() {
        RangoFuncionamiento rango = new RangoFuncionamiento(LocalDate.now().minusDays(1), LocalDate.now().plusDays(1));
        Tiquete t = new TiqueteTemporada(20000, false, Exclusividad.FAMILIAR, rango);
        assertTrue(validador.esValidoPara(t, atraccion, LocalDate.now()));
    }

    @Test
    void testEsValidoPara_TiqueteTemporadaFueraDeRango() {
        RangoFuncionamiento rango = new RangoFuncionamiento(LocalDate.now().minusDays(10), LocalDate.now().minusDays(5));
        Tiquete t = new TiqueteTemporada(20000, false, Exclusividad.FAMILIAR, rango);
        assertFalse(validador.esValidoPara(t, atraccion, LocalDate.now()));
    }

    @Test
    void testRegistrarUso() {
        Tiquete t = new TiqueteIndividual(7000, true, atraccion);
        assertFalse(t.isUsed());
        validador.registrarUso(t);
        assertTrue(t.isUsed());
    }

    @Test
    void testLogIntento() throws IOException {
        Tiquete t = new TiqueteIndividual(8000, true, atraccion);
        validador.logIntento(t, atraccion, LocalDate.now(), true);

        assertTrue(log.exists());

        try (BufferedReader reader = new BufferedReader(new FileReader(log))) {
            String line = reader.readLine();
            assertNotNull(line);
            assertTrue(line.contains("VALIDO"));
            assertTrue(line.contains(t.getCodigo()));
            assertTrue(line.contains(atraccion.getNombreAtraccion()));
        }
    }

    @Test
    void testRazonInvalidez_TiqueteUsado() {
        Tiquete t = new TiqueteIndividual(6000, true, atraccion);
        t.setUsado();
        String razon = validador.razonInvalidez(t, atraccion, LocalDate.now());
        assertEquals("Tiquete ya fue utilizado.", razon);
    }

    @Test
    void testRazonInvalidez_TiqueteTemporadaFueraDeFecha() {
        RangoFuncionamiento rango = new RangoFuncionamiento(LocalDate.now().minusDays(10), LocalDate.now().minusDays(5));
        Tiquete t = new TiqueteTemporada(20000, false, Exclusividad.FAMILIAR, rango);
        String razon = validador.razonInvalidez(t, atraccion, LocalDate.now());
        assertEquals("El tiquete no aplica a esta atracción o en esta fecha.", razon);
    }

    @Test
    void testRazonInvalidez_TiqueteValido() {
        Tiquete t = new TiqueteIndividual(5000, true, atraccion);
        String razon = validador.razonInvalidez(t, atraccion, LocalDate.now());
        assertEquals("Válido.", razon);
    }
}

