package Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import parque.ventas.*;
import parque.atraccion.*;
import parque.enumeraciones.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.tiquetes.*;

class OperadorMedioTest {

    private OperadorAtraccionRiesgoMedio operador;
    private AtraccionMecanica atraccion;
    private ValidadorTiquetes validador;

    @BeforeEach
    void setUp() {
        // Ubicación ficticia
        Ubicacion ubicacion = new Ubicacion("Zona Pirata", 2, "Isla del Tesoro #12");

        // Rango de fechas
        LocalDate inicio = LocalDate.of(2025, 5, 1);
        LocalDate fin = LocalDate.of(2025, 10, 31);
        RangoFuncionamiento rango = new RangoFuncionamiento(inicio, fin);

        // Restricciones
        List<RestriccionClima> clima = Arrays.asList(RestriccionClima.CALOR_EXTREMO);
        List<RestriccionSalud> salud = Arrays.asList(RestriccionSalud.DISCAPACIDAD_FISICA);

        // Crear atracción
        atraccion = new AtraccionMecanica(
            "Barco Pirata",
            ubicacion,
            25,
            2,
            Exclusividad.FAMILIAR,
            false,
            rango,
            clima,
            100,
            190,
            30,
            100,
            true,
            salud,
            Riesgo.MEDIO
        );

        // Crear operador
        operador = new OperadorAtraccionRiesgoMedio("ope2", "123", "Luis", 22);

        // Labor asignada
        Labor labor = new Labor(
            Dia.MIERCOLES,
            Turno.APERTURA,
            Actividad.TRABAJO_ESPECIALIZADO,
            atraccion,
            LocalDate.now()
        );
        operador.getLabores().add(labor);
        operador.getAtracciones().add(atraccion);

        validador = new ValidadorTiquetes("log-operador-medio.txt");
    }

    @AfterEach
    void tearDown() {
        File log = new File("log-operador-medio.txt");
        if (log.exists()) {
            log.delete();
        }
    }

    @Test
    void testValidarTiqueteCorrecto() {
        Tiquete t = new TiqueteIndividual(7000, true, atraccion);
        String resultado = operador.validarYRegistrarTiquete(t, atraccion, LocalDate.now(), validador);
        assertTrue(resultado.contains("Acceso concedido"));
        assertTrue(t.isUsed());
    }
}
