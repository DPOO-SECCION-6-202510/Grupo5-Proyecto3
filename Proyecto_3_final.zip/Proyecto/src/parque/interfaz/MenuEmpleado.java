package parque.interfaz;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import parque.usuarios.*;

public class MenuEmpleado extends JFrame {
    
    private VentanaInicial ventanaPrincipal;
    private Usuario usuarioActual;
    private Usuarios gestorUsuarios;
    private JPanel panelContenido;
    private List<String> turnosEmpleado;

    public MenuEmpleado(VentanaInicial ventanaPrincipal, Usuario usuarioActual, Usuarios gestorUsuarios) {
        this.ventanaPrincipal = ventanaPrincipal;
        this.usuarioActual = usuarioActual;
        this.gestorUsuarios = gestorUsuarios;
        this.turnosEmpleado = new ArrayList<>();
        
        // Agregar algunos turnos de ejemplo para el empleado
        turnosEmpleado.add("Lunes - 08:00 a 16:00 - Zona Montañas Rusas");
        turnosEmpleado.add("Martes - 10:00 a 18:00 - Zona Familiar");
        turnosEmpleado.add("Miércoles - 14:00 a 22:00 - Zona Terror");
        turnosEmpleado.add("Jueves - 08:00 a 16:00 - Zona Acuática");
        turnosEmpleado.add("Viernes - 16:00 a 24:00 - Zona Nocturna");

        setTitle("Menú Empleado - Parque Los Andes");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Panel superior con información del usuario
        JPanel panelSuperior = new JPanel(new FlowLayout());
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel labelBienvenida = new JLabel("Empleado: " + usuarioActual.getNombre() + " " + usuarioActual.getApellido());
        labelBienvenida.setFont(new Font("Arial", Font.BOLD, 16));
        panelSuperior.add(labelBienvenida);

        // Panel de botones
        JPanel panelBotones = new JPanel(new GridLayout(1, 2, 20, 10));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 80, 20, 80));

        JButton botonComprarDescuento = new JButton("Comprar Con Descuento");
        JButton botonVerTurnos = new JButton("Ver mis Turnos");

        // Configurar tamaño de botones
        Dimension tamañoBoton = new Dimension(180, 50);
        botonComprarDescuento.setPreferredSize(tamañoBoton);
        botonVerTurnos.setPreferredSize(tamañoBoton);

        // Configurar colores de botones
        botonComprarDescuento.setBackground(new Color(40, 167, 69));
        botonComprarDescuento.setForeground(Color.WHITE);
        botonVerTurnos.setBackground(new Color(23, 162, 184));
        botonVerTurnos.setForeground(Color.WHITE);

        panelBotones.add(botonComprarDescuento);
        panelBotones.add(botonVerTurnos);

        // Panel de contenido dinámico (parte intermedia e inferior)
        panelContenido = new JPanel(new BorderLayout());
        panelContenido.setBorder(BorderFactory.createTitledBorder("Área de Contenido"));
        panelContenido.setPreferredSize(new Dimension(550, 200));

        JLabel labelInicial = new JLabel("Sistema de gestión para empleados del parque", SwingConstants.CENTER);
        labelInicial.setFont(new Font("Arial", Font.ITALIC, 12));
        labelInicial.setForeground(Color.GRAY);
        panelContenido.add(labelInicial, BorderLayout.CENTER);

        // Panel inferior con botón cerrar sesión
        JPanel panelInferior = new JPanel(new FlowLayout());
        JButton botonCerrarSesion = new JButton("Cerrar Sesión");
        botonCerrarSesion.setPreferredSize(new Dimension(120, 30));
        botonCerrarSesion.setBackground(new Color(220, 53, 69));
        botonCerrarSesion.setForeground(Color.WHITE);
        panelInferior.add(botonCerrarSesion);

        // Agregar paneles al frame
        add(panelSuperior, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
        add(panelContenido, BorderLayout.SOUTH);
        add(panelInferior, BorderLayout.PAGE_END);

        // Eventos de los botones
        botonComprarDescuento.addActionListener(e -> mostrarComprarDescuento());
        botonVerTurnos.addActionListener(e -> mostrarTurnos());
        
        botonCerrarSesion.addActionListener(e -> {
            this.setVisible(false);
            ventanaPrincipal.setVisible(true);
        });
    }

    private void mostrarComprarDescuento() {
        panelContenido.removeAll();
        
        JPanel panelDescuento = new JPanel(new BorderLayout());
        
        JLabel titulo = new JLabel("Comprar Con Descuento de Empleado", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 14));
        panelDescuento.add(titulo, BorderLayout.NORTH);
        
        JLabel mensaje = new JLabel("<html><div style='text-align: center;'>" +
                "<br>Esta funcionalidad estará disponible próximamente.<br>" +
                "Aquí podrás comprar tiquetes con descuento especial para empleados.<br><br>" +
                "Descuento aplicable: 30% en todas las atracciones<br>" +
                "</div></html>", SwingConstants.CENTER);
        mensaje.setFont(new Font("Arial", Font.PLAIN, 12));
        mensaje.setForeground(new Color(102, 102, 102));
        panelDescuento.add(mensaje, BorderLayout.CENTER);
        
        panelContenido.add(panelDescuento, BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void mostrarTurnos() {
        panelContenido.removeAll();
        
        JPanel panelTurnos = new JPanel(new BorderLayout());
        
        JLabel titulo = new JLabel("Mis Turnos Asignados", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 14));
        panelTurnos.add(titulo, BorderLayout.NORTH);
        
        if (turnosEmpleado.isEmpty()) {
            JLabel mensaje = new JLabel("No tienes turnos asignados", SwingConstants.CENTER);
            mensaje.setFont(new Font("Arial", Font.ITALIC, 12));
            mensaje.setForeground(Color.GRAY);
            panelTurnos.add(mensaje, BorderLayout.CENTER);
        } else {
            JTextArea areaTurnos = new JTextArea();
            areaTurnos.setEditable(false);
            areaTurnos.setFont(new Font("Monospaced", Font.PLAIN, 12));
            
            StringBuilder textoTurnos = new StringBuilder();
            textoTurnos.append("TURNOS DE LA SEMANA:\n\n");
            
            for (String turno : turnosEmpleado) {
                String[] partes = turno.split(" - ");
                if (partes.length == 3) {
                    textoTurnos.append("► ").append(partes[0].toUpperCase()).append("\n");
                    textoTurnos.append("   Horario: ").append(partes[1]).append("\n");
                    textoTurnos.append("   Ubicación: ").append(partes[2]).append("\n\n");
                }
            }
            
            textoTurnos.append("Total de turnos asignados: ").append(turnosEmpleado.size());
            textoTurnos.append("\n\nNota: Para cambios en horarios, contacta al supervisor.");
            
            areaTurnos.setText(textoTurnos.toString());
            areaTurnos.setBackground(new Color(248, 249, 250));
            areaTurnos.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
            
            JScrollPane scrollPane = new JScrollPane(areaTurnos);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
            scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            panelTurnos.add(scrollPane, BorderLayout.CENTER);
        }
        
        panelContenido.add(panelTurnos, BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }
}