package parque.interfaz;

import javax.swing.*;
import java.awt.*;
import java.util.List;
import parque.usuarios.*;

public class ComprarTiquetes extends JDialog {
    
    private MenuClientes menuPadre;
    private Usuario usuarioActual;
    private List<String> tiquetesComprados;
    
    private JRadioButton radioBasico, radioFamiliar, radioOro, radioDiamante;
    private ButtonGroup grupoTiposTiquete;
    private JSpinner spinnerCantidad;
    private JCheckBox checkMontanaRusa, checkCasaTerror, checkRuedaFortuna, checkCarrosChocones;
    
    public ComprarTiquetes(MenuClientes menuPadre, Usuario usuarioActual, List<String> tiquetesComprados) {
        super(menuPadre, "Comprar Tiquetes - Parque Los Andes", true);
        this.menuPadre = menuPadre;
        this.usuarioActual = usuarioActual;
        this.tiquetesComprados = tiquetesComprados;
        
        setSize(500, 600);
        setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(menuPadre);
        
        initComponents();
    }
    
    private void initComponents() {
        setLayout(new BorderLayout());
        
        // Panel principal con scroll
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BoxLayout(panelPrincipal, BoxLayout.Y_AXIS));
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Título
        JLabel titulo = new JLabel("Comprar Tiquetes", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);
        panelPrincipal.add(titulo);
        panelPrincipal.add(Box.createVerticalStrut(20));
        
        // Panel de selección de tipo de tiquete
        JPanel panelTipoTiquete = new JPanel();
        panelTipoTiquete.setBorder(BorderFactory.createTitledBorder("Selecciona el Tipo de Tiquete"));
        panelTipoTiquete.setLayout(new GridLayout(4, 2, 5, 5));
        
        grupoTiposTiquete = new ButtonGroup();
        
        radioBasico = new JRadioButton("Básico - $15.000");
        radioFamiliar = new JRadioButton("Familiar - $45.000");
        radioOro = new JRadioButton("Oro - $75.000");
        radioDiamante = new JRadioButton("Diamante - $120.000");
        
        grupoTiposTiquete.add(radioBasico);
        grupoTiposTiquete.add(radioFamiliar);
        grupoTiposTiquete.add(radioOro);
        grupoTiposTiquete.add(radioDiamante);
        
        // Seleccionar Básico por defecto
        radioBasico.setSelected(true);
        
        panelTipoTiquete.add(radioBasico);
        panelTipoTiquete.add(new JLabel("Acceso al parque"));
        panelTipoTiquete.add(radioFamiliar);
        panelTipoTiquete.add(new JLabel("Acceso a todos los espectaculos y atracciones familiares"));
        panelTipoTiquete.add(radioOro);
        panelTipoTiquete.add(new JLabel("Acceso a todos los espectaculos y atracciones fam y oro"));
        panelTipoTiquete.add(radioDiamante);
        panelTipoTiquete.add(new JLabel("Acceso a todo lo que ofrece el parque"));
        
        panelPrincipal.add(panelTipoTiquete);
        panelPrincipal.add(Box.createVerticalStrut(15));
        
        // Panel de cantidad
        JPanel panelCantidad = new JPanel(new FlowLayout());
        panelCantidad.setBorder(BorderFactory.createTitledBorder("Selecciona la Cantidad"));
        
        JLabel labelCantidad = new JLabel("Cantidad de tiquetes:");
        spinnerCantidad = new JSpinner(new SpinnerNumberModel(1, 1, 10, 1));
        
        panelCantidad.add(labelCantidad);
        panelCantidad.add(spinnerCantidad);
        
        panelPrincipal.add(panelCantidad);
        panelPrincipal.add(Box.createVerticalStrut(15));
        
        // Panel de atracciones extras
        JPanel panelExtras = new JPanel();
        panelExtras.setBorder(BorderFactory.createTitledBorder("Atracciones Adicionales (Opcionales)"));
        panelExtras.setLayout(new GridLayout(4, 2, 5, 5));
        
        checkMontanaRusa = new JCheckBox("Montaña Rusa Extrema");
        checkCasaTerror = new JCheckBox("Casa del Terror");
        checkRuedaFortuna = new JCheckBox("Rueda de la Fortuna");
        checkCarrosChocones = new JCheckBox("Carros Chocones");
        
        panelExtras.add(checkMontanaRusa);
        panelExtras.add(new JLabel("+ $8.000"));
        panelExtras.add(checkCasaTerror);
        panelExtras.add(new JLabel("+ $6.000"));
        panelExtras.add(checkRuedaFortuna);
        panelExtras.add(new JLabel("+ $7.000"));
        panelExtras.add(checkCarrosChocones);
        panelExtras.add(new JLabel("+ $5.000"));
        
        panelPrincipal.add(panelExtras);
        panelPrincipal.add(Box.createVerticalStrut(20));
        
        // Panel resumen y total
        JPanel panelResumen = new JPanel();
        panelResumen.setBorder(BorderFactory.createTitledBorder("Resumen de Compra"));
        panelResumen.setLayout(new BorderLayout());
        
        JTextArea areaResumen = new JTextArea(5, 40);
        areaResumen.setEditable(false);
        areaResumen.setBackground(new Color(245, 245, 245));
        JScrollPane scrollResumen = new JScrollPane(areaResumen);
        
        panelResumen.add(scrollResumen, BorderLayout.CENTER);
        
        panelPrincipal.add(panelResumen);
        
        // Botón para actualizar resumen
        JButton botonActualizarResumen = new JButton("Actualizar Resumen");
        botonActualizarResumen.setAlignmentX(Component.CENTER_ALIGNMENT);
        botonActualizarResumen.addActionListener(e -> actualizarResumen(areaResumen));
        
        panelPrincipal.add(Box.createVerticalStrut(10));
        panelPrincipal.add(botonActualizarResumen);
        
        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout());
        
        JButton botonComprar = new JButton("Confirmar Compra");
        botonComprar.setBackground(new Color(40, 167, 69));
        botonComprar.setForeground(Color.WHITE);
        botonComprar.setFont(new Font("Arial", Font.BOLD, 12));
        
        JButton botonCancelar = new JButton("Cancelar");
        botonCancelar.setBackground(new Color(220, 53, 69));
        botonCancelar.setForeground(Color.WHITE);
        
        panelBotones.add(botonComprar);
        panelBotones.add(botonCancelar);
        
        // Eventos de botones
        botonComprar.addActionListener(e -> confirmarCompra());
        botonCancelar.addActionListener(e -> dispose());
        
        // Agregar componentes al frame
        JScrollPane scrollPrincipal = new JScrollPane(panelPrincipal);
        add(scrollPrincipal, BorderLayout.CENTER);
        add(panelBotones, BorderLayout.SOUTH);
        
        // Actualizar resumen inicial
        actualizarResumen(areaResumen);
    }
    
    private void actualizarResumen(JTextArea areaResumen) {
        StringBuilder resumen = new StringBuilder();
        int total = 0;
        
        // Tipo de tiquete seleccionado
        String tipoTiquete = "";
        int precioBase = 0;
        
        if (radioBasico.isSelected()) {
            tipoTiquete = "Básico";
            precioBase = 15000;
        } else if (radioFamiliar.isSelected()) {
            tipoTiquete = "Familiar";
            precioBase = 45000;
        } else if (radioOro.isSelected()) {
            tipoTiquete = "Oro";
            precioBase = 75000;
        } else if (radioDiamante.isSelected()) {
            tipoTiquete = "Diamante";
            precioBase = 120000;
        }
        
        int cantidad = (Integer) spinnerCantidad.getValue();
        int subtotal = precioBase * cantidad;
        
        resumen.append("RESUMEN DE COMPRA\n");
        resumen.append("=====================================\n");
        resumen.append("Tipo de Tiquete: ").append(tipoTiquete).append("\n");
        resumen.append("Precio unitario: $").append(String.format("%,d", precioBase)).append("\n");
        resumen.append("Cantidad: ").append(cantidad).append("\n");
        resumen.append("Subtotal: $").append(String.format("%,d", subtotal)).append("\n\n");
        
        total += subtotal;
        
        // Atracciones adicionales
        resumen.append("ATRACCIONES ADICIONALES:\n");
        int extrasTotal = 0;
        
        if (checkMontanaRusa.isSelected()) {
            int precio = 8000 * cantidad;
            extrasTotal += precio;
            resumen.append("• Montaña Rusa Extrema: $").append(String.format("%,d", precio)).append("\n");
        }
        if (checkCasaTerror.isSelected()) {
            int precio = 6000 * cantidad;
            extrasTotal += precio;
            resumen.append("• Casa del Terror: $").append(String.format("%,d", precio)).append("\n");
        }
        if (checkRuedaFortuna.isSelected()) {
            int precio = 7000 * cantidad;
            extrasTotal += precio;
            resumen.append("• Rueda de la Fortuna: $").append(String.format("%,d", precio)).append("\n");
        }
        if (checkCarrosChocones.isSelected()) {
            int precio = 5000 * cantidad;
            extrasTotal += precio;
            resumen.append("• Carros Chocones: $").append(String.format("%,d", precio)).append("\n");
        }
        
        if (extrasTotal == 0) {
            resumen.append("• Ninguna seleccionada\n");
        }
        
        total += extrasTotal;
        
        resumen.append("\n=====================================\n");
        resumen.append("TOTAL A PAGAR: $").append(String.format("%,d", total)).append("\n");
        resumen.append("=====================================");
        
        areaResumen.setText(resumen.toString());
    }
    
    private void confirmarCompra() {
        // Generar tiquete
        String tipoTiquete = "";
        if (radioBasico.isSelected()) tipoTiquete = "Básico";
        else if (radioFamiliar.isSelected()) tipoTiquete = "Familiar";
        else if (radioOro.isSelected()) tipoTiquete = "Oro";
        else if (radioDiamante.isSelected()) tipoTiquete = "Diamante";
        
        int cantidad = (Integer) spinnerCantidad.getValue();
        
        String tiquete = "Tiquete #" + String.format("%03d", tiquetesComprados.size() + 1) + 
                        " - Tipo: " + tipoTiquete + " - Cantidad: " + cantidad;
        
        tiquetesComprados.add(tiquete);
        
        JOptionPane.showMessageDialog(this, 
            "¡Compra realizada exitosamente!\n\n" + tiquete, 
            "Compra Exitosa", 
            JOptionPane.INFORMATION_MESSAGE);
        
        dispose();
    }
}