package parque.interfaz;

import	java.awt.*;
import java.io.IOException;

import	javax.swing.*;

import com.google.zxing.WriterException;

import parque.tiquetes.*;
import parque.enumeraciones.*;
import parque.interfaz.*;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.*;
import java.awt.*;

public class Impresora extends JFrame {

    public Impresora(TiqueteRegular t) {
        setTitle("Imprimir boleta");
        setSize(900, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(255, 179, 102));
        panel.setLayout(null);
        add(panel);

        JLabel titulo = new JLabel("Parque de Atracciones");
        titulo.setFont(new Font("Serif", Font.BOLD, 28));
        titulo.setBounds(250, 20, 600, 30);
        panel.add(titulo);

        JLabel numero = new JLabel("No. " + t.codigo);
        numero.setFont(new Font("SansSerif", Font.PLAIN, 18));
        numero.setBounds(30, 50, 200, 30);
        panel.add(numero);
        
        Exclusividad e = t.getCategoria();
        JLabel tipo = new JLabel("Tiquete: " + e.name());
        tipo.setBounds(30, 100, 200, 20);
        panel.add(tipo);
        
        LocalDate fecha_ = t.fechaExpedicion;
        JLabel fecha = new JLabel("Fecha Expedición: " + fecha_.toString());
        fecha.setBounds(30, 130, 200, 20);
        panel.add(fecha);

        String p = String.valueOf(t.precio);
        JLabel valor = new JLabel("Valor: $" + p);
        valor.setBounds(30, 160, 200, 20);
        panel.add(valor);

        JLabel dia = new JLabel(fecha_.toString());
        dia.setFont(new Font("SansSerif", Font.BOLD, 22));
        dia.setBounds(350, 420, 300, 30);
        panel.add(dia);

        ImageIcon qrIcon = new ImageIcon("qrcode.png");
        JLabel qrLabel = new JLabel();
        qrLabel.setIcon(new ImageIcon(qrIcon.getImage().getScaledInstance(220, 220, Image.SCALE_SMOOTH)));
        qrLabel.setBounds(640, 120, 220, 220);
        panel.add(qrLabel);
    }

    public static void main(String[] args) {
    	
    	double precio = Precios.BASICO.getPrecio();
    	TiqueteRegular t = new TiqueteRegular(precio, true, Exclusividad.BASICO);
    	Exclusividad ex = t.getCategoria();
    	LocalDate fecha = t.fechaExpedicion;
    	QRCodeGenerator qr = new QRCodeGenerator();
    	String mensaje = "Tiquete " + ex.name() + "\n" +
    			         "Fecha Expedicion: " + fecha.toString() + "\n" +
    			         "ID: " + t.codigo; 
    	
    	try {
            qr.generateQR(mensaje, 300, 300, "qrcode.png");
        } catch (WriterException | IOException e) {
            e.printStackTrace();
        }
    	
        SwingUtilities.invokeLater(() -> {
            Impresora ventana = new Impresora(t);
            ventana.setVisible(true);
        });
    }
}

