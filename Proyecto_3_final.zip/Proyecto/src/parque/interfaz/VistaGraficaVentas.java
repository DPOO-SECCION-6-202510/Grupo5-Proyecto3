package parque.interfaz;

import javax.swing.*;
import java.awt.*;
import java.util.Map;
import java.util.LinkedHashMap;

public class VistaGraficaVentas extends JPanel {

    private Map<String, Integer> ventasMensuales;

    public VistaGraficaVentas() {
        // Datos ficticios para cada mes del año
        ventasMensuales = new LinkedHashMap<>();
        ventasMensuales.put("Enero", 120);
        ventasMensuales.put("Febrero", 90);
        ventasMensuales.put("Marzo", 150);
        ventasMensuales.put("Abril", 180);
        ventasMensuales.put("Mayo", 200);
        ventasMensuales.put("Junio", 160);
        ventasMensuales.put("Julio", 220);
        ventasMensuales.put("Agosto", 190);
        ventasMensuales.put("Septiembre", 170);
        ventasMensuales.put("Octubre", 210);
        ventasMensuales.put("Noviembre", 130);
        ventasMensuales.put("Diciembre", 250);

        JFrame frame = new JFrame("Gráfica de Ventas Anuales");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(800, 500);
        frame.add(this);
        frame.setVisible(true);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g;
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();
        int padding = 60;
        int labelPadding = 25;
        int maxVenta = ventasMensuales.values().stream().max(Integer::compare).orElse(1);

        int barWidth = (width - 2 * padding) / ventasMensuales.size();
        int x = padding;

        g2.drawString("Ventas por Mes", width / 2 - 40, padding / 2);

        // Dibujar ejes
        g2.drawLine(padding, height - padding, width - padding, height - padding); // eje x
        g2.drawLine(padding, padding, padding, height - padding); // eje y

        // Dibujar barras
        int i = 0;
        for (Map.Entry<String, Integer> entry : ventasMensuales.entrySet()) {
            int value = entry.getValue();
            int barHeight = (int) ((double) value / maxVenta * (height - 2 * padding));
            int y = height - padding - barHeight;

            g2.setColor(new Color(79, 129, 189));
            g2.fillRect(x + i * barWidth + 10, y, barWidth - 20, barHeight);

            g2.setColor(Color.BLACK);
            g2.drawString(entry.getKey(), x + i * barWidth + 10, height - padding + 15);
            g2.drawString(String.valueOf(value), x + i * barWidth + 15, y - 5);

            i++;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(VistaGraficaVentas::new);
    }
}