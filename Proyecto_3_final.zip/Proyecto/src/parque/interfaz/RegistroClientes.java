package parque.interfaz;

import javax.swing.*;
import java.awt.*;
import parque.usuarios.*;
import parque.usuarios.Usuario.TipoUsuario;
import parque.data.*;

public class RegistroClientes extends JFrame {

    private JTextField campoNombre;
    private JTextField campoApellido;
    private JTextField campoUsuario;
    private JPasswordField campoClave;
    private JPasswordField campoConfirmarClave;
    private VentanaInicial ventanaPrincipal;
    private Usuarios gestorUsuarios;

    public RegistroClientes(VentanaInicial ventanaPrincipal, Usuarios gestorUsuarios) {
        this.ventanaPrincipal = ventanaPrincipal;
        this.gestorUsuarios = gestorUsuarios;

        setTitle("Registro de Clientes");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // Título
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JLabel titulo = new JLabel("Registro de Nuevo Cliente");
        titulo.setFont(new Font("Arial", Font.BOLD, 16));
        panel.add(titulo, gbc);

        // Nombre
        gbc.gridwidth = 1;
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Nombre:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        campoNombre = new JTextField();
        campoNombre.setPreferredSize(new Dimension(200, 25));
        panel.add(campoNombre, gbc);

        // Apellido
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Apellido:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        campoApellido = new JTextField();
        campoApellido.setPreferredSize(new Dimension(200, 25));
        panel.add(campoApellido, gbc);

        // Usuario
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Usuario:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        campoUsuario = new JTextField();
        campoUsuario.setPreferredSize(new Dimension(200, 25));
        panel.add(campoUsuario, gbc);

        // Clave
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Contraseña:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        campoClave = new JPasswordField();
        campoClave.setPreferredSize(new Dimension(200, 25));
        panel.add(campoClave, gbc);

        // Confirmar Clave
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.anchor = GridBagConstraints.EAST;
        panel.add(new JLabel("Confirmar Contraseña:"), gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        campoConfirmarClave = new JPasswordField();
        campoConfirmarClave.setPreferredSize(new Dimension(200, 25));
        panel.add(campoConfirmarClave, gbc);

        // Nota informativa
        gbc.gridx = 0;
        gbc.gridy++;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JLabel nota = new JLabel("<html><div style='text-align: center; font-size: 10px; color: gray;'>"
                + "Nota: Los nuevos registros se crearán como clientes"
                + "</div></html>");
        panel.add(nota, gbc);

        // Botones
        gbc.gridy++;
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.CENTER;

        JButton botonCancelar = new JButton("Cancelar");
        botonCancelar.setPreferredSize(new Dimension(100, 30));
        panel.add(botonCancelar, gbc);

        gbc.gridx = 1;
        JButton botonRegistrar = new JButton("Registrarse");
        botonRegistrar.setPreferredSize(new Dimension(120, 30));
        panel.add(botonRegistrar, gbc);

        add(panel);

        // Acción botón cancelar
        botonCancelar.addActionListener(e -> {
            this.setVisible(false);
            ventanaPrincipal.setVisible(true);
        });

        // Acción botón registrar
        botonRegistrar.addActionListener(e -> {
            String nombre = campoNombre.getText().trim();
            String apellido = campoApellido.getText().trim();
            String usuario = campoUsuario.getText().trim();
            String clave = new String(campoClave.getPassword());
            String confirmarClave = new String(campoConfirmarClave.getPassword());

            if (nombre.isEmpty() || apellido.isEmpty() || usuario.isEmpty() || clave.isEmpty() || confirmarClave.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, complete todos los campos.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!clave.equals(confirmarClave)) {
                JOptionPane.showMessageDialog(this, "Las contraseñas no coinciden.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Verificar si el usuario ya existe
            if (gestorUsuarios.existeUsuario(usuario)) {
                JOptionPane.showMessageDialog(this, "El nombre de usuario ya está registrado. Por favor, elija otro.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Validar longitud mínima de contraseña
            if (clave.length() < 4) {
                JOptionPane.showMessageDialog(this, "La contraseña debe tener al menos 4 caracteres.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            // Crear nuevo cliente (por defecto será CLIENTE)
            Usuario nuevoCliente = new Usuario(nombre, usuario, clave, false, TipoUsuario.CLIENTE) {};
            gestorUsuarios.agregarUsuario(nuevoCliente);

            JOptionPane.showMessageDialog(this, 
                "¡Registro exitoso!\n" +
                "Bienvenido/a: " + nombre + " " + apellido + "\n" +
                "Ya puede iniciar sesión con sus credenciales.", 
                "Registro Completado", 
                JOptionPane.INFORMATION_MESSAGE);

            // Limpiar campos
            campoNombre.setText("");
            campoApellido.setText("");
            campoUsuario.setText("");
            campoClave.setText("");
            campoConfirmarClave.setText("");

            this.setVisible(false);
            ventanaPrincipal.setVisible(true);
        });
    }
}