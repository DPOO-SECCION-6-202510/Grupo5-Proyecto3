package parque.interfaz;

import javax.swing.*;
import java.awt.*;
import parque.usuarios.*;
import parque.data.*;

public class VentanaInicial extends JFrame {

    private JTextField campoUsuario;
    private JPasswordField campoClave;
    private Usuarios gestorUsuarios; // Instancia única para manejar usuarios

    public VentanaInicial() {
        // Inicializar el gestor de usuarios (esto creará automáticamente admin, empleado y cliente ejemplo)
        gestorUsuarios = new Usuarios();
        
        setTitle("Parque de Atracciones Los Andes");
        setSize(600, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panelPrincipal = new JPanel(new GridBagLayout());
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;

        // Logo 
        ImageIcon logoIcon = new ImageIcon("imagenes/logo.png");
        Image img = logoIcon.getImage();
        Image imgEscalada = img.getScaledInstance(150, 160, Image.SCALE_SMOOTH);
        logoIcon = new ImageIcon(imgEscalada);
        JLabel labelLogo = new JLabel(logoIcon);
        labelLogo.setHorizontalAlignment(SwingConstants.CENTER);
        panelPrincipal.add(labelLogo, gbc);

        // Título
        gbc.gridy++;
        JLabel labelTitulo = new JLabel("PARQUE DE DIVERSIONES LOS ANDES");
        labelTitulo.setFont(new Font("Arial", Font.BOLD, 22));
        labelTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        panelPrincipal.add(labelTitulo, gbc);

        // Texto principal
        gbc.gridy++;
        JLabel labelBienvenida = new JLabel("<html><div style='text-align: center;'>"
                + "!Bienvenido al lugar perfecto para pasar un día inolvidable!"
                + "</div></html>");
        labelBienvenida.setFont(new Font("Arial", Font.PLAIN, 14));
        labelBienvenida.setHorizontalAlignment(SwingConstants.CENTER);
        panelPrincipal.add(labelBienvenida, gbc);

        // Texto catálogo
        gbc.gridy++;
        JLabel labelCatalogoTexto = new JLabel("<html><div style='text-align: center;'>"
                + "Consulte nuestro catálogo de atracciones y espectáculos."
                + "</div></html>");
        labelCatalogoTexto.setFont(new Font("Arial", Font.PLAIN, 14));
        labelCatalogoTexto.setHorizontalAlignment(SwingConstants.CENTER);
        panelPrincipal.add(labelCatalogoTexto, gbc);

        // CATALOGO
        gbc.gridy++;
        JButton botonVerCatalogo = new JButton("Ver Catálogo del Parque");
        botonVerCatalogo.setPreferredSize(new Dimension(200, 30));
        panelPrincipal.add(botonVerCatalogo, gbc);

        // Texto para comprar tiquetes
        gbc.gridy++;
        JLabel labelCompraTexto = new JLabel("<html><div style='text-align: center;'>"
                + "Para comprar o ver sus tiquetes, debe iniciar sesión.<br>"
                + "Si no tiene una cuenta creada, debe registrarse."
                + "</div></html>");
        labelCompraTexto.setFont(new Font("Arial", Font.PLAIN, 14));
        labelCompraTexto.setHorizontalAlignment(SwingConstants.CENTER);
        panelPrincipal.add(labelCompraTexto, gbc);

        // Campos de inicio de sesión
        gbc.gridy++;
        gbc.gridwidth = 1;
        gbc.anchor = GridBagConstraints.EAST;
        JLabel labelUsuario = new JLabel("Usuario:");
        panelPrincipal.add(labelUsuario, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        campoUsuario = new JTextField();
        campoUsuario.setPreferredSize(new Dimension(200, 25));
        panelPrincipal.add(campoUsuario, gbc);

        // Contraseña
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.EAST;
        JLabel labelClave = new JLabel("Contraseña:");
        panelPrincipal.add(labelClave, gbc);

        gbc.gridx = 1;
        gbc.anchor = GridBagConstraints.WEST;
        campoClave = new JPasswordField();
        campoClave.setPreferredSize(new Dimension(200, 25));
        panelPrincipal.add(campoClave, gbc);

        // BOTONES
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.anchor = GridBagConstraints.CENTER;

        JButton botonIniciarSesion = new JButton("Iniciar Sesión");
        botonIniciarSesion.setPreferredSize(new Dimension(120, 30));
        panelPrincipal.add(botonIniciarSesion, gbc);

        gbc.gridx = 1;
        JButton botonRegistrarse = new JButton("Registrarse");
        botonRegistrarse.setPreferredSize(new Dimension(120, 30));
        panelPrincipal.add(botonRegistrarse, gbc);

        // Información de usuarios de ejemplo (opcional - para desarrollo)
        gbc.gridy++;
        gbc.gridx = 0;
        gbc.gridwidth = 2;
        gbc.anchor = GridBagConstraints.CENTER;
        JLabel labelInfo = new JLabel("<html><div style='text-align: center; font-size: 10px; color: gray;'>"
                + "Usuarios de ejemplo:<br>"
                + "Admin: admin/admin123 | Empleado: empleado/emp123 | Cliente: cliente/cli123"
                + "</div></html>");
        panelPrincipal.add(labelInfo, gbc);

        add(panelPrincipal);

        // Acción botón registrarse
        botonRegistrarse.addActionListener(e -> {
            this.setVisible(false); 
            RegistroClientes registro = new RegistroClientes(this, gestorUsuarios);
            registro.setVisible(true);
        });

        // Acción botón iniciar sesión
        botonIniciarSesion.addActionListener(e -> {
            String usuario = campoUsuario.getText().trim();
            String clave = new String(campoClave.getPassword());

            if (usuario.isEmpty() || clave.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Por favor, ingrese usuario y contraseña.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            Usuario usuarioValido = gestorUsuarios.validarCredenciales(usuario, clave);
            
            if (usuarioValido != null) {
                // Limpiar campos
                campoUsuario.setText("");
                campoClave.setText("");
                
                // Ocultar ventana actual
                this.setVisible(false);
                
                // Abrir el menú correspondiente según el tipo de usuario
                
                switch (usuarioValido.getTipoUsuario()) {
                /*
                    case ADMINISTRADOR:
                        JOptionPane.showMessageDialog(this, "Bienvenido Administrador: " + usuarioValido.getNombre(), 
                                                    "Acceso Autorizado", JOptionPane.INFORMATION_MESSAGE);
                        new MenuAdmin(this, usuarioValido, gestorUsuarios).setVisible(true);
                        break;
                        
                    case EMPLEADO:
                        JOptionPane.showMessageDialog(this, "Bienvenido Empleado: " + usuarioValido.getNombre(), 
                                                    "Acceso Autorizado", JOptionPane.INFORMATION_MESSAGE);
                        new MenuEmpleado(this, usuarioValido, gestorUsuarios).setVisible(true);
                        break;
                 */
                    case CLIENTE:
                        JOptionPane.showMessageDialog(this, "Bienvenido: " + usuarioValido.getNombre(), 
                                                    "Inicio de Sesión Exitoso", JOptionPane.INFORMATION_MESSAGE);
                        new MenuClientes(this, usuarioValido, gestorUsuarios).setVisible(true);
                        break;
                }
                
            } else {
                JOptionPane.showMessageDialog(this, "Usuario o contraseña incorrectos.", "Error de Autenticación", JOptionPane.ERROR_MESSAGE);
            }
        });
    }
	
    // Getter para que otras clases puedan acceder al gestor de usuarios
    public Usuarios getGestorUsuarios() {
        return gestorUsuarios;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new VentanaInicial().setVisible(true);
        });
    }
}