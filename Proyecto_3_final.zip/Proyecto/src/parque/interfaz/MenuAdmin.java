package parque.interfaz;

import javax.swing.*;
import java.awt.*;
import parque.usuarios.*;

public class MenuAdmin extends JFrame {
    
    private VentanaInicial ventanaPrincipal;
    private Usuario usuarioActual;
    private Usuarios gestorUsuarios;

    public MenuAdmin(VentanaInicial ventanaPrincipal, Usuario usuarioActual, Usuarios gestorUsuarios) {
        this.ventanaPrincipal = ventanaPrincipal;
        this.usuarioActual = usuarioActual;
        this.gestorUsuarios = gestorUsuarios;

        setTitle("Menú Administrador - Parque Los Andes");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        // Panel superior con información del usuario
        JPanel panelSuperior = new JPanel(new FlowLayout());
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelSuperior.setBackground(new Color(52, 58, 64));
        
        JLabel labelBienvenida = new JLabel("Administrador: " + usuarioActual.getNombre() + " " + usuarioActual.getApellido());
        labelBienvenida.setFont(new Font("Arial", Font.BOLD, 16));
        labelBienvenida.setForeground(Color.WHITE);
        panelSuperior.add(labelBienvenida);

        // Panel central con los botones principales
        JPanel panelCentral = new JPanel(new GridLayout(2, 2, 20, 20));
        panelCentral.setBorder(BorderFactory.createEmptyBorder(50, 50, 50, 50));

        // Crear los cuatro botones
        JButton botonRegistrarEmpleado = new JButton("Registrar Nuevo Empleado");
        JButton botonRegistrarAtraccion = new JButton("Registrar Atracción");
        JButton botonRegistrarEspectaculo = new JButton("Registrar Espectáculo");
        JButton botonGestionarEmpleado = new JButton("Gestionar Empleado");

        // Configurar estilo de los botones
        Dimension tamañoBoton = new Dimension(200, 60);
        Font fuenteBoton = new Font("Arial", Font.BOLD, 12);
        
        // Botón Registrar Empleado
        botonRegistrarEmpleado.setPreferredSize(tamañoBoton);
        botonRegistrarEmpleado.setBackground(new Color(40, 167, 69));
        botonRegistrarEmpleado.setForeground(Color.WHITE);
        botonRegistrarEmpleado.setFont(fuenteBoton);
        
        // Botón Registrar Atracción
        botonRegistrarAtraccion.setPreferredSize(tamañoBoton);
        botonRegistrarAtraccion.setBackground(new Color(255, 193, 7));
        botonRegistrarAtraccion.setForeground(new Color(33, 37, 41));
        botonRegistrarAtraccion.setFont(fuenteBoton);
        
        // Botón Registrar Espectáculo
        botonRegistrarEspectaculo.setPreferredSize(tamañoBoton);
        botonRegistrarEspectaculo.setBackground(new Color(23, 162, 184));
        botonRegistrarEspectaculo.setForeground(Color.WHITE);
        botonRegistrarEspectaculo.setFont(fuenteBoton);
        
        // Botón Gestionar Empleado
        botonGestionarEmpleado.setPreferredSize(tamañoBoton);
        botonGestionarEmpleado.setBackground(new Color(108, 117, 125));
        botonGestionarEmpleado.setForeground(Color.WHITE);
        botonGestionarEmpleado.setFont(fuenteBoton);

        // Agregar botones al panel central
        panelCentral.add(botonRegistrarEmpleado);
        panelCentral.add(botonRegistrarAtraccion);
        panelCentral.add(botonRegistrarEspectaculo);
        panelCentral.add(botonGestionarEmpleado);

        // Panel inferior con botón cerrar sesión
        JPanel panelInferior = new JPanel(new FlowLayout());
        JButton botonCerrarSesion = new JButton("Cerrar Sesión");
        botonCerrarSesion.setPreferredSize(new Dimension(120, 30));
        botonCerrarSesion.setBackground(new Color(220, 53, 69));
        botonCerrarSesion.setForeground(Color.WHITE);
        panelInferior.add(botonCerrarSesion);

        // Agregar paneles al frame
        add(panelSuperior, BorderLayout.NORTH);
        add(panelCentral, BorderLayout.CENTER);
        add(panelInferior, BorderLayout.SOUTH);

        // Eventos de los botones (por ahora solo mensajes)
        botonRegistrarEmpleado.addActionListener(e -> 
            JOptionPane.showMessageDialog(this, "Funcionalidad: Registrar Nuevo Empleado\n(Por implementar)")
        );
        
        botonRegistrarAtraccion.addActionListener(e -> 
            JOptionPane.showMessageDialog(this, "Funcionalidad: Registrar Atracción\n(Por implementar)")
        );
        
        botonRegistrarEspectaculo.addActionListener(e -> 
            JOptionPane.showMessageDialog(this, "Funcionalidad: Registrar Espectáculo\n(Por implementar)")
        );
        
        botonGestionarEmpleado.addActionListener(e -> 
            JOptionPane.showMessageDialog(this, "Funcionalidad: Gestionar Empleado\n(Por implementar)")
        );
        
        botonCerrarSesion.addActionListener(e -> {
            this.setVisible(false);
            ventanaPrincipal.setVisible(true);
        });
    }
}