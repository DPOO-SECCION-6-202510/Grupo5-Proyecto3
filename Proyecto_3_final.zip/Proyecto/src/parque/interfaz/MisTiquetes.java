package parque.interfaz;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class MisTiquetes extends JDialog {
    private List<String> tiquetesComprados;

    public MisTiquetes(Frame parent, List<String> tiquetesComprados) {
        super(parent, "Mis Tiquetes Comprados", true);
        this.tiquetesComprados = tiquetesComprados;
        setSize(400, 300);
        setLocationRelativeTo(parent);
        setLayout(new BorderLayout());

        JLabel titulo = new JLabel("Mis Tiquetes Comprados", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 16));
        add(titulo, BorderLayout.NORTH);

        JTextArea areaTiquetes = new JTextArea();
        areaTiquetes.setEditable(false);
        areaTiquetes.setFont(new Font("Arial", Font.PLAIN, 12));
        areaTiquetes.setLineWrap(true);
        areaTiquetes.setWrapStyleWord(true);

        StringBuilder textoTiquetes = new StringBuilder();
        if (tiquetesComprados.isEmpty()) {
            textoTiquetes.append("No has comprado tiquetes aún.");
        } else {
            for (String tiquete : tiquetesComprados) {
                textoTiquetes.append(tiquete).append("\n");
            }
        }
        areaTiquetes.setText(textoTiquetes.toString());

        JScrollPane scrollPane = new JScrollPane(areaTiquetes);
        add(scrollPane, BorderLayout.CENTER);

        JButton botonCerrar = new JButton("Cerrar");
        botonCerrar.addActionListener(e -> dispose());
        JPanel panelBoton = new JPanel();
        panelBoton.add(botonCerrar);
        add(panelBoton, BorderLayout.SOUTH);
    }
}

