package parque.interfaz;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import parque.usuarios.*;
import parque.data.*;

public class MenuClientes extends JFrame {
    
    private VentanaInicial ventanaPrincipal;
    private Usuario usuarioActual;
    private Usuarios gestorUsuarios;
    private JPanel panelContenido;
    private List<String> tiquetesComprados;

    public MenuClientes(VentanaInicial ventanaPrincipal, Usuario usuarioActual, Usuarios gestorUsuarios) {
        this.ventanaPrincipal = ventanaPrincipal;
        this.usuarioActual = usuarioActual;
        this.gestorUsuarios = gestorUsuarios;
        this.tiquetesComprados = new ArrayList<>();
        
        // Agregar algunos tiquetes de ejemplo
        tiquetesComprados.add("Tiquete #001 - Tipo: Básico - Cantidad: 2");
        tiquetesComprados.add("Tiquete #002 - Tipo: Familiar - Cantidad: 1");

        setTitle("Menú Cliente - Parque Los Andes");
        setSize(600, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        initComponents();
    }

    private void initComponents() {
        setLayout(new BorderLayout());

        
        JPanel panelSuperior = new JPanel(new FlowLayout());
        panelSuperior.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        panelSuperior.setBackground(new Color(52, 73, 94));
        
        JLabel labelBienvenida = new JLabel("Bienvenido: " + usuarioActual.getNombre());
        labelBienvenida.setFont(new Font("Arial", Font.BOLD, 16));
        labelBienvenida.setForeground(Color.WHITE);
        panelSuperior.add(labelBienvenida);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JButton botonComprarTiquetes = new JButton("Comprar Tiquetes");
        JButton botonVerTiquetes = new JButton("Ver mis Tiquetes");
        JButton botonImprimirTiquetes = new JButton("Imprimir Tiquetes");

     
        Dimension tamañoBoton = new Dimension(200, 40);
        Font fuenteBoton = new Font("Arial", Font.BOLD, 12);
        
        botonComprarTiquetes.setPreferredSize(tamañoBoton);
        botonComprarTiquetes.setBackground(new Color(40, 167, 69));
        botonComprarTiquetes.setForeground(Color.WHITE);
        botonComprarTiquetes.setFont(fuenteBoton);
        
        botonVerTiquetes.setPreferredSize(tamañoBoton);
        botonVerTiquetes.setBackground(new Color(23, 162, 184));
        botonVerTiquetes.setForeground(Color.WHITE);
        botonVerTiquetes.setFont(fuenteBoton);
        
        botonImprimirTiquetes.setPreferredSize(tamañoBoton);
        botonImprimirTiquetes.setBackground(new Color(255, 193, 7));
        botonImprimirTiquetes.setForeground(new Color(33, 37, 41));
        botonImprimirTiquetes.setFont(fuenteBoton);

        panelBotones.add(botonComprarTiquetes);
        panelBotones.add(botonVerTiquetes);
        panelBotones.add(botonImprimirTiquetes);

   
        panelContenido = new JPanel(new BorderLayout());
        panelContenido.setBorder(BorderFactory.createTitledBorder("Área de Contenido"));
        panelContenido.setPreferredSize(new Dimension(550, 200));

        mostrarPanelInicial();

        JPanel panelInferior = new JPanel(new FlowLayout());
        JButton botonCerrarSesion = new JButton("Cerrar Sesión");
        botonCerrarSesion.setPreferredSize(new Dimension(120, 30));
        botonCerrarSesion.setBackground(new Color(220, 53, 69));
        botonCerrarSesion.setForeground(Color.WHITE);
        panelInferior.add(botonCerrarSesion);

    
        add(panelSuperior, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
        add(panelContenido, BorderLayout.SOUTH);
        add(panelInferior, BorderLayout.PAGE_END);

      
        botonComprarTiquetes.addActionListener(e -> abrirVentanaComprarTiquetes());
        botonVerTiquetes.addActionListener(e -> {
            MisTiquetes ventanaTiquetes = new MisTiquetes(this, tiquetesComprados);
            ventanaTiquetes.setVisible(true);
        });
        botonImprimirTiquetes.addActionListener(e -> imprimirTiquetes());
        
        botonCerrarSesion.addActionListener(e -> {
            this.setVisible(false);
            ventanaPrincipal.setVisible(true);
        });
    }

    private void mostrarPanelInicial() {
        panelContenido.removeAll();
        
        JPanel panelInicial = new JPanel(new BorderLayout());
        
        JLabel labelInicial = new JLabel("Bienvenido al sistema de tiquetes del parque", SwingConstants.CENTER);
        labelInicial.setFont(new Font("Arial", Font.ITALIC, 14));
        labelInicial.setForeground(Color.GRAY);
        
        JPanel panelInfo = new JPanel(new GridLayout(3, 1, 10, 10));
        panelInfo.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));
        
        JLabel info1 = new JLabel("• Compra tus tiquetes de forma fácil y rápida", SwingConstants.CENTER);
        JLabel info2 = new JLabel("• Ve todos tus tiquetes comprados", SwingConstants.CENTER);
        JLabel info3 = new JLabel("• Imprime tus tiquetes cuando lo necesites", SwingConstants.CENTER);
        
        info1.setFont(new Font("Arial", Font.PLAIN, 12));
        info2.setFont(new Font("Arial", Font.PLAIN, 12));
        info3.setFont(new Font("Arial", Font.PLAIN, 12));
        
        panelInfo.add(info1);
        panelInfo.add(info2);
        panelInfo.add(info3);
        
        panelInicial.add(labelInicial, BorderLayout.NORTH);
        panelInicial.add(panelInfo, BorderLayout.CENTER);
        
        panelContenido.add(panelInicial, BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void abrirVentanaComprarTiquetes() {
        ComprarTiquetes ventanaCompra = new ComprarTiquetes(this, usuarioActual, tiquetesComprados);
        ventanaCompra.setVisible(true); 
        mostrarMisTiquetes(); 
    }

    private void mostrarMisTiquetes() {
        panelContenido.removeAll();
        
        JPanel panelTiquetes = new JPanel(new BorderLayout());
        
        JLabel titulo = new JLabel("Mis Tiquetes Comprados", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 14));
        titulo.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        panelTiquetes.add(titulo, BorderLayout.NORTH);
        
        if (tiquetesComprados.isEmpty()) {
            JLabel mensaje = new JLabel("No has comprado tiquetes aún", SwingConstants.CENTER);
            mensaje.setFont(new Font("Arial", Font.ITALIC, 12));
            mensaje.setForeground(Color.GRAY);
            panelTiquetes.add(mensaje, BorderLayout.CENTER);
        } else {
            
            JPanel panelListaTiquetes = new JPanel();
            panelListaTiquetes.setLayout(new BoxLayout(panelListaTiquetes, BoxLayout.Y_AXIS));
            panelListaTiquetes.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
            
            
            for (int i = 0; i < tiquetesComprados.size(); i++) {
                String tiquete = tiquetesComprados.get(i);
                
                JPanel panelTiquete = new JPanel(new BorderLayout());
                panelTiquete.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(new Color(200, 200, 200)),
                    BorderFactory.createEmptyBorder(8, 12, 8, 12)
                ));
                panelTiquete.setBackground(Color.WHITE);
                
                JLabel labelTiquete = new JLabel(tiquete);
                labelTiquete.setFont(new Font("Arial", Font.PLAIN, 11));
                
                JLabel labelNumero = new JLabel("#" + (i + 1));
                labelNumero.setFont(new Font("Arial", Font.BOLD, 10));
                labelNumero.setForeground(new Color(108, 117, 125));
                
                panelTiquete.add(labelNumero, BorderLayout.WEST);
                panelTiquete.add(labelTiquete, BorderLayout.CENTER);
                
                panelListaTiquetes.add(panelTiquete);
                panelListaTiquetes.add(Box.createVerticalStrut(5));
            }
            
            
            JPanel panelTotal = new JPanel(new FlowLayout());
            panelTotal.setBorder(BorderFactory.createEmptyBorder(10, 0, 0, 0));
            
            JLabel labelTotal = new JLabel("Total de tiquetes: " + tiquetesComprados.size());
            labelTotal.setFont(new Font("Arial", Font.BOLD, 12));
            labelTotal.setForeground(new Color(40, 167, 69));
            panelTotal.add(labelTotal);
            
            panelListaTiquetes.add(panelTotal);
            
            JScrollPane scrollPane = new JScrollPane(panelListaTiquetes);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
            scrollPane.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
            
            panelTiquetes.add(scrollPane, BorderLayout.CENTER);
        }
        
       
        JPanel panelBotonVolver = new JPanel(new FlowLayout());
        JButton botonVolver = new JButton("Volver");
        botonVolver.addActionListener(e -> mostrarPanelInicial());
        panelBotonVolver.add(botonVolver);
        panelTiquetes.add(panelBotonVolver, BorderLayout.SOUTH);
        
        panelContenido.add(panelTiquetes, BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    private void imprimirTiquetes() {
        if (tiquetesComprados.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No tienes tiquetes para imprimir", "Sin Tiquetes", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        panelContenido.removeAll();
        
        JPanel panelImprimir = new JPanel(new BorderLayout());
        
        JLabel titulo = new JLabel("Vista Previa de Impresión", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 14));
        titulo.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        panelImprimir.add(titulo, BorderLayout.NORTH);
        
        JTextArea areaImpresion = new JTextArea();
        areaImpresion.setEditable(false);
        areaImpresion.setFont(new Font("Courier New", Font.PLAIN, 10));
        areaImpresion.setBackground(new Color(248, 249, 250));
        
        StringBuilder textoImpresion = new StringBuilder();
        textoImpresion.append("==========================================\n");
        textoImpresion.append("      PARQUE DE DIVERSIONES LOS ANDES    \n");
        textoImpresion.append("==========================================\n\n");
        textoImpresion.append("Cliente: ").append(usuarioActual.getNombre()).append("\n");
        textoImpresion.append("Fecha: ").append(java.time.LocalDate.now()).append("\n\n");
        textoImpresion.append("TIQUETES COMPRADOS:\n");
        textoImpresion.append("------------------------------------------\n");
        
        for (String tiquete : tiquetesComprados) {
            textoImpresion.append(tiquete).append("\n");
        }
        
        textoImpresion.append("------------------------------------------\n");
        textoImpresion.append("Total de tiquetes: ").append(tiquetesComprados.size()).append("\n");
        textoImpresion.append("\n¡Disfruta tu visita al parque!\n");
        textoImpresion.append("==========================================");
        
        areaImpresion.setText(textoImpresion.toString());
        
        JScrollPane scrollPane = new JScrollPane(areaImpresion);
        panelImprimir.add(scrollPane, BorderLayout.CENTER);
        
        JPanel panelBotones = new JPanel(new FlowLayout());
        
        JButton botonConfirmarImpresion = new JButton("Confirmar Impresión");
        botonConfirmarImpresion.setBackground(new Color(40, 167, 69));
        botonConfirmarImpresion.setForeground(Color.WHITE);
        botonConfirmarImpresion.addActionListener(e -> {
            JOptionPane.showMessageDialog(this, "Tiquetes enviados a la impresora", "Impresión Exitosa", JOptionPane.INFORMATION_MESSAGE);
        });
        
        JButton botonVolver = new JButton("Volver");
        botonVolver.addActionListener(e -> mostrarPanelInicial());
        
        panelBotones.add(botonConfirmarImpresion);
        panelBotones.add(botonVolver);
        panelImprimir.add(panelBotones, BorderLayout.SOUTH);
        
        panelContenido.add(panelImprimir, BorderLayout.CENTER);
        panelContenido.revalidate();
        panelContenido.repaint();
    }

    
    public List<String> getTiquetesComprados() {
        return tiquetesComprados;
    }
}