package parque.atraccion;

import java.util.ArrayList;
import java.util.List;


import parque.modelo.LugarDeTrabajo;
import parque.modelo.RangoFuncionamiento;
import parque.modelo.Ubicacion;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;

public abstract class Atraccion implements LugarDeTrabajo{
	
	
	private String nombreAtraccion;
	private Ubicacion ubicacionFija;
	private int capacidadMaxima;
	private int minimoEmpleados;
	private Exclusividad exclusividad;
	private boolean esDeTemporada;
	private RangoFuncionamiento rangoTiempoFuncionamiento;
	private List<RestriccionClima> restriccionesPorClima = new ArrayList<RestriccionClima>();
	
	
	

	public Atraccion(String nombreAtraccion, Ubicacion ubicacionFija, int capacidadMaxima,int minimoEmpleados, Exclusividad exclusividad, boolean esDeTemporada,RangoFuncionamiento rangoTiempoFuncionamiento, List<RestriccionClima> restriccionesPorClima) {
		this.nombreAtraccion = nombreAtraccion;
		this.ubicacionFija = ubicacionFija;
		this.capacidadMaxima = capacidadMaxima;
		this.minimoEmpleados = minimoEmpleados;
		this.exclusividad = exclusividad;
		this.esDeTemporada = esDeTemporada;
		this.rangoTiempoFuncionamiento = rangoTiempoFuncionamiento;
		if (restriccionesPorClima != null) {
			this.restriccionesPorClima = restriccionesPorClima;
		}
	}


	public String getNombreAtraccion() {
		return nombreAtraccion;
	}
	
	public Ubicacion getUbicacion() {
		return ubicacionFija;
	}
	
	public int getMinimoEmpleados() {
		return minimoEmpleados;
	}
	
	public int getCapacidadMaxima() {
		return capacidadMaxima;
	}
	
	public Exclusividad getExclusividad() {
		return exclusividad;
	}
	
	public boolean isDeTemporada() {
		return esDeTemporada;
	}
	
	public RangoFuncionamiento getRangoFuncionamiento() {
		return rangoTiempoFuncionamiento;
	}
	
	public List<RestriccionClima> getRestriccionesClima(){
		return restriccionesPorClima;
	}

}
