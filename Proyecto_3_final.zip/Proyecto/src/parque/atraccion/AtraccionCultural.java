package parque.atraccion;

import java.util.List;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;


import parque.modelo.RangoFuncionamiento;
import parque.modelo.Ubicacion;

public class AtraccionCultural extends Atraccion{
	
	private boolean tieneRestriccionEdad;
	private int edadMinima;
	
	public AtraccionCultural(String nombreAtraccion, Ubicacion ubicacion, int capacidadMaxima,int minimoEmpleados, Exclusividad exclusividad, boolean esDeTemporada,RangoFuncionamiento rangoFuncionamiento, List<RestriccionClima> restriccionesPorClima, boolean restriccionEdad, int edadMinima) {
		super(nombreAtraccion, ubicacion, capacidadMaxima, minimoEmpleados, exclusividad,esDeTemporada, rangoFuncionamiento, restriccionesPorClima);
		this.tieneRestriccionEdad = restriccionEdad;
		this.edadMinima = edadMinima;
	}
	
	
	public boolean hasRestriccionEdad() {
		return tieneRestriccionEdad;
	}
	
	public int getEdadMinima() {
		return edadMinima;
	}

}
