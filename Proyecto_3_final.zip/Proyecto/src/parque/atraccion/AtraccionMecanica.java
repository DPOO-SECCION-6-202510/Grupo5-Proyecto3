package parque.atraccion;

import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;

import java.util.ArrayList;
import java.util.List;

import parque.modelo.RangoFuncionamiento;
import parque.modelo.Ubicacion;

public class AtraccionMecanica extends Atraccion{
	
	private int alturaMinima;
	private int alturaMaxima;
	private int pesoMinimo;
	private int pesoMaximo;
	private boolean tieneRestriccionSalud;
	private List<RestriccionSalud> restriccionesPorSalud = new ArrayList<RestriccionSalud>();
	private Riesgo nivelRiesgo;
	
	
	public AtraccionMecanica(String nombreAtraccion, Ubicacion ubicacion, int capacidadMaxima,int minimoEmpleados, Exclusividad exclusividad, boolean esDeTemporada,RangoFuncionamiento rangoFuncionamiento, List<RestriccionClima> restriccionesPorClima,int alturaMinima, int alturaMaxima, int pesoMinimo, int pesoMaximo,boolean tieneRestriccionSalud, List<RestriccionSalud> restriccionesPorSalud,Riesgo nivelRiesgo) {

		super(nombreAtraccion, ubicacion, capacidadMaxima, minimoEmpleados, exclusividad,esDeTemporada, rangoFuncionamiento, restriccionesPorClima);

		this.alturaMinima = alturaMinima;
		this.alturaMaxima = alturaMaxima;
		this.pesoMinimo = pesoMinimo;
		this.pesoMaximo = pesoMaximo;
		this.tieneRestriccionSalud = tieneRestriccionSalud;
		if (restriccionesPorSalud != null) {
			this.restriccionesPorSalud = restriccionesPorSalud;
		}
		this.nivelRiesgo = nivelRiesgo;
	}
	
	
	public int getAlturaMinima() {
		return alturaMinima;
	}
	
	public int getAlturaMaxima() {
		return alturaMaxima;
	}
	
	public int getPesoMinimo() {
		return pesoMinimo;
	}
	
	public int getPesoMaximo() {
		return pesoMaximo;
	}
	
	public boolean hasRestriccionSalud() {
		return tieneRestriccionSalud;
	}
	
	public List<RestriccionSalud> getRestriccionesSalud(){
		return restriccionesPorSalud;
	}
	
	public Riesgo getRiesgo() {
		return nivelRiesgo;
	}

}
