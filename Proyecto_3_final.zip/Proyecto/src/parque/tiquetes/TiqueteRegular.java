package parque.tiquetes;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;
import parque.atraccion.*;
import java.util.HashSet;
import java.util.Set;

public class TiqueteRegular extends Tiquete {
	
	protected Exclusividad categoria;
	
	public TiqueteRegular(double precio, boolean usoUnico, Exclusividad categoria) {
		super(precio, usoUnico);
		this.categoria = categoria;
	}

	public Exclusividad getCategoria() {
		return this.categoria;
	}
	
	public String toRegistro() {
	    return String.format("INDIVIDUAL;%s;%b;%b;%s",
	            getCodigo(), isUsed(), usoUnico, categoria);
	}
	
	
}
