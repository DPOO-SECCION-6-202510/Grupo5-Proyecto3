package parque.tiquetes;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;
import parque.atraccion.*;

public abstract class Tiquete {
	
	public static Set<String> codigos = new HashSet<String>( );
	public String codigo;
	public double precio;
	public boolean usado;
	public boolean usoUnico;
	public LocalDate fechaExpedicion;
	
	public Tiquete (double precio, boolean usoUnico) {
		this.precio = precio;
		this.usoUnico = usoUnico;
		this.usado = false;
		this.fechaExpedicion = LocalDate.now();
		
		
		int numero = ( int ) ( Math.random( ) * 10e7 );
        String codigo = "" + numero;
        while( codigos.contains( codigo ) )
        {
            numero = ( int ) ( Math.random( ) * 10e7 );
            codigo = "" + numero;
        }

        while( codigo.length( ) < 7 )
            codigo = "0" + codigo;
        
        this.codigo = codigo;     
	}
	
	public abstract String toRegistro();
	
	public boolean isUsed () {
		return this.usado;
	}
	
	public void setUsado() {
		this.usado = true;
	}
	
	public String getCodigo() {
		return this.codigo;
	}
	
	public LocalDate getFechaExpedicion() {
		return this.fechaExpedicion;
	}
	
	public Tiquete desdeRegistro(String linea, ParqueAtracciones parque) { return null;}; //Para implementar CargarVentas
}
