package parque.tiquetes;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;
import parque.atraccion.*;
import java.util.Set;

public class TiqueteTemporada extends TiqueteRegular {
	
	protected RangoFuncionamiento rangoFechas;
	
	public TiqueteTemporada(double precio, boolean usoUnico, Exclusividad categoria, RangoFuncionamiento rangoFechas) {
		super(precio, usoUnico, categoria);
		this.rangoFechas = rangoFechas;
	}

	public RangoFuncionamiento getRangoFechas() {
		return this.rangoFechas;
	}
	
	public String toRegistro() {
	    StringBuilder sb = new StringBuilder();
	    sb.append(String.format("TEMPORADA;%s;%b;%b;%s;%s;%s",
	    	    getCodigo(), isUsed(), usoUnico,
	    	    rangoFechas.getInicio(), rangoFechas.getFin(), categoria));
	    return sb.toString();
	}
}
