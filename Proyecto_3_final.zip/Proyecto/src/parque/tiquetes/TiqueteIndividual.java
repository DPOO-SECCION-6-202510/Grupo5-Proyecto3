package parque.tiquetes;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;
import parque.atraccion.*;
public class TiqueteIndividual extends Tiquete {
	
	private Atraccion atraccion;
	
	public TiqueteIndividual(double precio, boolean usoUnico, Atraccion atraccion) {
		super(precio, usoUnico);
		this.atraccion = atraccion;
	}
	
	public Atraccion getAtraccion() {
		return this.atraccion;
	}
	
	@Override
	public String toRegistro() {
	    return String.format("INDIVIDUAL;%s;%b;%b;%s",
	    	    getCodigo(), isUsed(), usoUnico, getAtraccion().getNombreAtraccion());
	}
	
}
