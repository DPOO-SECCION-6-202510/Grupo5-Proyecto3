package parque.tiquetes;
import java.util.Date;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;
import parque.atraccion.*;

public class FastPass extends Tiquete {
	
	private Date fecha;

	public FastPass(double precio, boolean usoUnico, Date fecha) {
		super(precio, usoUnico);
		this.fecha = fecha;
	}
	
	public Date getFecha() {
		return this.fecha;
	}
	@Override
	public String toRegistro() {
	    return String.format("FASTPASS;%s;%b;%b;%s",
	    	    getCodigo(), isUsed(), usoUnico, getFecha().toString());
	}
}