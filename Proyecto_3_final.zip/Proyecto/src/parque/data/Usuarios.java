package parque.data;

import java.util.ArrayList;
import java.util.List;
import parque.usuarios.*;
import parque.usuarios.Usuario.TipoUsuario;

public class Usuarios {

    private List<Usuario> listaUsuarios;

    public Usuarios() {
        listaUsuarios = new ArrayList<>();
        // Crear automáticamente usuarios del sistema
        crearUsuariosSistema();
    }

    /**
     * Crea los usuarios por defecto del sistema
     */
    private void crearUsuariosSistema() {
        // Crear administrador
    	ParqueAtracciones parque = new ParqueAtracciones("Parque de Atracciones");
        Administrador admin = new Administrador("Administrador", "admin", "admin123", parque);
        listaUsuarios.add(admin);
        
        // Crear empleado de ejemplo
        Empleado empleado = new Empleado("Juan", "empleado", "emp123", 20) {};
        listaUsuarios.add(empleado);
        
        // Opcional: crear un cliente de ejemplo para pruebas
        Usuario clienteEjemplo = new Usuario("María", "cliente", "cli123", false, TipoUsuario.CLIENTE) {};
        listaUsuarios.add(clienteEjemplo);
    }

    /**
     * Agrega un nuevo usuario a la lista
     */
    public void agregarUsuario(Usuario nuevo) {
        listaUsuarios.add(nuevo);
    }

    /**
     * Verifica si un nombre de usuario ya está registrado
     */
    public boolean existeUsuario(String nombreUsuario) {
        for (Usuario u : listaUsuarios) {
            if (u.getLogin().equalsIgnoreCase(nombreUsuario)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Valida las credenciales de un usuario
     */
    public Usuario validarCredenciales(String usuario, String clave) {
        for (Usuario u : listaUsuarios) {
            if (u.getLogin().equalsIgnoreCase(usuario) && u.getPassword().equals(clave)) {
                return u;
            }
        }
        return null; // Credenciales inválidas
    }

    /**
     * Devuelve todos los usuarios registrados
     */
    public List<Usuario> getUsuarios() {
        return new ArrayList<>(listaUsuarios);
    }

    /**
    
    public List<Usuario> getUsuariosPorTipo(TipoUsuario tipo) {
        List<Usuario> usuariosTipo = new ArrayList<>();
        for (Usuario u : listaUsuarios) {
            if (u.getTipoUsuario() == tipo) {
                usuariosTipo.add(u);
            }
        }
        return usuariosTipo;
    }

    public int getCantidadUsuarios() {
        return listaUsuarios.size();
    }


    public int getCantidadUsuariosPorTipo(TipoUsuario tipo) {
        return getUsuariosPorTipo(tipo).size();
    }
    */
}