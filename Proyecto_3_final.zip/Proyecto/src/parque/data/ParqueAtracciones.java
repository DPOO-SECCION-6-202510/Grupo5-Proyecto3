package parque.data;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.atraccion.*;
import parque.usuarios.*;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class ParqueAtracciones {
	//Agregar un método que saque las atracciones BASICO, ORO, DIAMANTE, ETC...
	protected String nombre;
	protected int numAtracciones;
	protected int numEspectaculos;
	protected ArrayList<Atraccion> atracciones;
	protected ArrayList<Espectaculo> espectaculos;
	protected int numEmpleados;
	protected ArrayList<Empleado> empleados;
	protected ArrayList<Atraccion> atraccionesBasico;
	protected ArrayList<Atraccion> atraccionesFamiliar;
	protected ArrayList<Atraccion> atraccionesOro;
	
	public ParqueAtracciones(String nombre) {
        this.nombre = nombre;
        this.numAtracciones = 0;
        this.numEmpleados = 0;
        this.numEspectaculos = 0;
        this.empleados = new ArrayList<Empleado>();
        this.atracciones = new ArrayList<Atraccion>();
        this.atraccionesBasico = new ArrayList<Atraccion>();
        this.atraccionesFamiliar = new ArrayList<Atraccion>();
        this.atraccionesOro = new ArrayList<Atraccion>();
        this.espectaculos = new ArrayList<>();
    }
	
	public Atraccion buscarAtraccionPorNombre(String nombreBuscado) {
		for (Atraccion a : atracciones) {
	        if (a.getNombreAtraccion().equalsIgnoreCase(nombreBuscado)) {
	            return a;
	        }
	    }
	    return null;
	}
    public List<Empleado> getEmpleados() {
        return empleados;
    }

    public List<Atraccion> getAtracciones() {
        return atracciones;
    }

    public List<Espectaculo> getEspectaculos() {
        return espectaculos;
    }

    public void mostrarCatalogo(String rutaArchivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(rutaArchivo))) {
            bw.write("--- Catálogo de Atracciones ---\n");
            for (Atraccion a : atracciones) {
                bw.write(a.toString());
                bw.newLine();
            }

            bw.write("\n--- Catálogo de Espectáculos ---\n");
            for (Espectaculo e : espectaculos) {
                bw.write(e.toString());
                bw.newLine();
            }

            System.out.println("Catálogo generado en: " + rutaArchivo);
        } catch (IOException e) {
            System.err.println("Error al escribir catálogo: " + e.getMessage());
        }
    }

    public void generarInformeAdministrador(String rutaArchivo) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(rutaArchivo))) {
            bw.write("--- INFORME PARA ADMINISTRADORES ---\n");
            bw.write("Nombre del parque: " + nombre + "\n\n");

            bw.write("Empleados registrados: " + empleados.size() + "\n");
            for (Empleado emp : empleados) {
                bw.write(emp.toString());
                bw.newLine();
            }

            bw.write("\nTotal de atracciones: " + atracciones.size() + "\n");
            bw.write("Total de espectáculos: " + espectaculos.size() + "\n");

            System.out.println("Informe de administrador generado en: " + rutaArchivo);
        } catch (IOException e) {
            System.err.println("Error al escribir informe: " + e.getMessage());
        }
    }
}
