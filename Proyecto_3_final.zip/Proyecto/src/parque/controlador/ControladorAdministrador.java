package parque.controlador;
import parque.usuarios.*;
import parque.modelo.*;
import parque.ventas.*;
import parque.atraccion.*;
import parque.tiquetes.*;
import parque.enumeraciones.*;
import parque.data.*;
import parque.interfaz.QRCodeGenerator;
import com.google.zxing.WriterException;

import java.time.LocalDate;
import java.sql.Date;
import java.util.*;
import java.io.IOException;

class ControladorAdministrador {
    private Administrador admin;
    private ParqueAtracciones parque;

    public ControladorAdministrador(Administrador admin, ParqueAtracciones parque) {
        this.admin = admin;
        this.parque = parque;
    }

    // EMPLEADOS
    public void registrarEmpleado(Empleado emp) {
        parque.getEmpleados().add(emp);
    }

    public void asignarTurno(Empleado emp, Labor labor) {
        emp.getLabores().add(labor);
    }

    // ATRACCIONES
    public void registrarAtraccion(Atraccion atraccion) {
        parque.getAtracciones().add(atraccion);
    }

    public void eliminarAtraccion(Atraccion atraccion) {
        parque.getAtracciones().remove(atraccion);
    }

    public void modificarAtraccion(String nombre, Atraccion nueva) {
        Atraccion existente = parque.buscarAtraccionPorNombre(nombre);
        if (existente != null) {
            parque.getAtracciones().remove(existente);
            parque.getAtracciones().add(nueva);
        }
    }

    // ESPECTÁCULOS
    public void registrarEspectaculo(Espectaculo e) {
        parque.getEspectaculos().add(e);
    }

    public void eliminarEspectaculo(Espectaculo e) {
        parque.getEspectaculos().remove(e);
    }

    public void modificarEspectaculo(String nombre, Espectaculo nuevo) {
        for (int i = 0; i < parque.getEspectaculos().size(); i++) {
            if (parque.getEspectaculos().get(i).getNombre().equals(nombre)) {
                parque.getEspectaculos().set(i, nuevo);
                return;
            }
        }
    }

    // TIQUETES
    public void comprarTiqueteComoAdmin(String tipo, String nombreAtraccion, Exclusividad exclusividad, RangoFuncionamiento rango) {
        Tiquete t = null;
        switch (tipo) {
            case "individual" -> t = GestorVentas.venderTiqueteIndividual(admin, nombreAtraccion, Precios.INDIVIDUAL.getPrecio());
            case "regular" -> t = GestorVentas.venderTiqueteRegular(admin, exclusividad, Precios.valueOf(exclusividad.name()));
            case "temporada" -> t = GestorVentas.venderTiqueteTemporada(admin, exclusividad, rango, Precios.valueOf(exclusividad.name()));
            case "fastpass" -> t = GestorVentas.venderFastPass(admin, new Date(System.currentTimeMillis()), Precios.FASTPASS.getPrecio());
        }
        if (t != null) generarQRParaTiquete(t);
    }

    private void generarQRParaTiquete(Tiquete t) {
        String textoQR = t.toRegistro();
        String filePath = "qr/" + t.getCodigo() + ".png";
        QRCodeGenerator qr = new QRCodeGenerator();
        try {
            qr.generateQR(textoQR, 300, 300, filePath);
        } catch (WriterException | IOException e) {
            System.err.println("❌ Error generando QR: " + e.getMessage());
        }
    }

    public void generarCatalogo(String ruta) {
        parque.mostrarCatalogo(ruta);
    }

    public void generarInforme(String ruta) {
        parque.generarInformeAdministrador(ruta);
    }
}