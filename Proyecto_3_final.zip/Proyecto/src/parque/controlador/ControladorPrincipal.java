package parque.controlador;

import parque.usuarios.*;
import parque.usuarios.Usuario;
import parque.usuarios.Usuario.TipoUsuario;
import parque.modelo.*;
import parque.ventas.*;
import parque.atraccion.*;
import parque.tiquetes.*;
import parque.enumeraciones.*;
import parque.data.*;
import parque.interfaz.QRCodeGenerator;
import com.google.zxing.WriterException;

import java.time.LocalDate;
import java.sql.Date;
import java.util.*;
import java.io.IOException;

public class ControladorPrincipal {
    private ParqueAtracciones parque;

    public ControladorPrincipal(ParqueAtracciones parque) {
        this.parque = parque;
    }

    public void autenticarUsuario(String login, String password) {
        // Buscar usuario (implementación depende de cómo cargues los usuarios)
        // Redirigir al controlador correspondiente
    }

    public void registrarUsuario(String nombre, String login, String pass, int edad, double peso) {
        Usuario nuevo = new Usuario(nombre, login, pass, false, TipoUsuario.CLIENTE){}; // Clase anónima, puede ser reemplazada por una subclase si es necesario
        nuevo.setEdad(edad);
        nuevo.setPeso(peso);
        // Persistir nuevo usuario en archivo
    }
}