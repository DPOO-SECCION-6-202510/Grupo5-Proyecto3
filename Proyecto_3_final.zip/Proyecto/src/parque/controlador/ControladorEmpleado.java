package parque.controlador;
import parque.usuarios.*;
import parque.modelo.*;
import parque.ventas.*;
import parque.atraccion.*;
import parque.tiquetes.*;
import parque.enumeraciones.*;
import parque.data.*;
import parque.interfaz.QRCodeGenerator;
import com.google.zxing.WriterException;

import java.time.LocalDate;
import java.sql.Date;
import java.util.*;
import java.io.IOException;

class ControladorEmpleado {
    private Empleado empleado;
    private ParqueAtracciones parque;

    public ControladorEmpleado(Empleado empleado, ParqueAtracciones parque) {
        this.empleado = empleado;
        this.parque = parque;
    }

    public List<Labor> verTurnos() {
        return empleado.getLabores();
    }

    public void comprarTiquete(String tipo, String nombreAtraccion, Exclusividad exclusividad, RangoFuncionamiento rango) {
        Tiquete t = null;
        switch (tipo) {
            case "individual" -> t = GestorVentas.venderTiqueteIndividual(empleado, nombreAtraccion, Precios.INDIVIDUAL.getPrecio());
            case "regular" -> t = GestorVentas.venderTiqueteRegular(empleado, exclusividad, Precios.valueOf(exclusividad.name()));
            case "temporada" -> t = GestorVentas.venderTiqueteTemporada(empleado, exclusividad, rango, Precios.valueOf(exclusividad.name()));
            case "fastpass" -> t = GestorVentas.venderFastPass(empleado, new Date(System.currentTimeMillis()), Precios.FASTPASS.getPrecio());
        }
        if (t != null) generarQRParaTiquete(t);
    }

    private void generarQRParaTiquete(Tiquete t) {
        String textoQR = t.toRegistro();
        String filePath = "qr/" + t.getCodigo() + ".png";
        QRCodeGenerator qr = new QRCodeGenerator();
        try {
            qr.generateQR(textoQR, 300, 300, filePath);
        } catch (WriterException | IOException e) {
            System.err.println("❌ Error generando QR: " + e.getMessage());
        }
    }
}
