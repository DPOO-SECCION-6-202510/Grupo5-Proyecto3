package parque.controlador;
import parque.usuarios.*;
import parque.modelo.*;
import parque.ventas.*;
import parque.tiquetes.*;
import parque.enumeraciones.*;
import parque.data.*;
import parque.interfaz.QRCodeGenerator;
import com.google.zxing.WriterException;

import java.time.LocalDate;
import java.sql.Date;
import java.util.*;
import java.io.IOException;

class ControladorCliente {
    private Usuario usuario;
    private ParqueAtracciones parque;

    public ControladorCliente(Usuario usuario, ParqueAtracciones parque) {
        this.usuario = usuario;
        this.parque = parque;
    }

    public void comprarTiqueteIndividual(String nombreAtraccion, double precio) {
        TiqueteIndividual t = GestorVentas.venderTiqueteIndividual(usuario, nombreAtraccion, precio);
        generarQRParaTiqueteIndividual(t);
    }

    public void comprarTiqueteRegular(Exclusividad categoria, Precios precio) {
        TiqueteRegular t = GestorVentas.venderTiqueteRegular(usuario, categoria, precio);
        generarQRParaTiqueteRegular(t);
    }

    public void comprarTiqueteTemporada(Exclusividad categoria, RangoFuncionamiento rango, Precios precio) {
        TiqueteTemporada t = GestorVentas.venderTiqueteTemporada(usuario, categoria, rango, precio);
        generarQRParaTiqueteTemporada(t);
    }

    public void comprarFastPass(Date fecha, double precio) {
        FastPass t = GestorVentas.venderFastPass(usuario, fecha, precio);
        generarQRParaFastPass(t);
    }

    private void generarQRParaTiqueteRegular(TiqueteRegular t) {
    	
    	Exclusividad ex = t.getCategoria();
    	LocalDate fecha = t.fechaExpedicion;
    	QRCodeGenerator qr = new QRCodeGenerator();
    	String mensaje = "Tiquete " + ex.name() + "\n" +
    			         "Fecha Expedicion: " + fecha.toString() + "\n" +
    			         "ID: " + t.codigo; 
    	
    	try {
            qr.generateQR(mensaje, 300, 300, "qrcode.png");
        } catch (WriterException | IOException e) {
            e.printStackTrace();
        }
    }
    
    private void generarQRParaTiqueteIndividual(TiqueteIndividual t) {}
    
    private void generarQRParaTiqueteTemporada(TiqueteTemporada t) {}
    
    private void generarQRParaFastPass(FastPass t) {}

    public List<Tiquete> verTiquetes() {
        List<Tiquete> todos = new ArrayList<>();
        todos.addAll(usuario.getTiquetesIndividuales());
        todos.addAll(usuario.getTiquetesRegulares());
        todos.addAll(usuario.getTiquetesFastPass());
        todos.addAll(usuario.getTiquetesTemporada());
        return todos;
    }

    public void consultarCatalogo(String ruta) {
        usuario.consultarCatalogo(parque, ruta);
    }
}

