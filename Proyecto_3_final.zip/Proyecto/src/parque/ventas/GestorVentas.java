package parque.ventas;

import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;
import parque.atraccion.*;
import java.io.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;

public class GestorVentas {
    private static List<Tiquete> tiquetesVendidos;
    private static File archivoVentas;
    private static ParqueAtracciones parque;
    private static Map<String, Double> descuentosMensuales; // usuario -> total descuento mes actual

    private static final double DESCUENTO_EMPLEADO = 0.2;
    private static final double LIMITE_DESCUENTO_MENSUAL = 100000.0;

    public GestorVentas(String rutaArchivo, ParqueAtracciones parque) {
        this.tiquetesVendidos = new ArrayList<>();
        this.archivoVentas = new File(rutaArchivo);
        this.parque = parque;
        this.descuentosMensuales = new HashMap<>();

        if (archivoVentas.exists()) {
            cargarVentas();
        }
    }

    public static TiqueteRegular venderTiqueteRegular(Usuario usuario, Exclusividad tipo , Precios precio) { //Quitar eso de listas
        //LLamar al constructor de Tiquete Regular
    	double valor = precio.getPrecio();
        TiqueteRegular tiquete = new TiqueteRegular(valor, true, tipo);
        return (TiqueteRegular) registrarVenta(usuario, tiquete);
    }

    public static TiqueteIndividual venderTiqueteIndividual(Usuario usuario, String nombreAtraccion, double precioBase) {
        Atraccion a = parque.buscarAtraccionPorNombre(nombreAtraccion);
        if (a == null) throw new IllegalArgumentException("Atracción no encontrada.");

        double precioFinal = aplicarDescuentoSiEmpleado(usuario, precioBase);
        TiqueteIndividual tiquete = new TiqueteIndividual(precioFinal, true, a);
        return (TiqueteIndividual) registrarVenta(usuario, tiquete);
    }

    public static FastPass venderFastPass(Usuario usuario, Date fecha, double precioBase) {

        double precioFinal = aplicarDescuentoSiEmpleado(usuario, precioBase);
        FastPass fastPass = new FastPass(precioFinal, true, fecha);
        return (FastPass) registrarVenta(usuario, fastPass);
    }

    public static TiqueteTemporada venderTiqueteTemporada(Usuario usuario, Exclusividad tipo, RangoFuncionamiento rangoFuncionamiento, Precios precio) {
    	double valor = precio.getPrecio();
    	TiqueteTemporada tiquete = new TiqueteTemporada(valor, false, tipo, rangoFuncionamiento);
    	return (TiqueteTemporada) registrarVenta(usuario, tiquete);
    }

    private static double aplicarDescuentoSiEmpleado(Usuario usuario, double precioBase) {
        if (!usuario.esEmpleado()) return precioBase;

        String id = usuario.getLogin();
        YearMonth mesActual = YearMonth.now();
        String clave = id + ":" + mesActual;

        double descuentoActual = descuentosMensuales.getOrDefault(clave, 0.0);
        double posibleDescuento = precioBase * DESCUENTO_EMPLEADO;

        if (descuentoActual + posibleDescuento > LIMITE_DESCUENTO_MENSUAL) {
            return precioBase; // supera el límite, no se aplica descuento
        }

        // aplicar descuento
        descuentosMensuales.put(clave, descuentoActual + posibleDescuento);
        return precioBase - posibleDescuento;
    }

    private static Tiquete registrarVenta(Usuario usuario, Tiquete tiquete) {
        tiquetesVendidos.add(tiquete);
        usuario.agregarTiquete(tiquete);
        guardarVenta(tiquete);
        return tiquete;
    }

    public static void invalidarTiquete(Tiquete tiquete) {
        tiquete.setUsado();
        actualizarArchivoVentas();
    }

    private static void guardarVenta(Tiquete tiquete) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivoVentas, true))) {
            bw.write(tiquete.toRegistro());
            bw.newLine();
        } catch (IOException e) {
            System.err.println("Error al guardar venta: " + e.getMessage());
        }
    }
    
    //Para futuras implementaciones, queremos que el metodo "desdeRegistro" reconstruya un objeto a partir del texto que sdalga del archivo con la informacion
    //de cada uno de los tiquetes
    private static void cargarVentas() {
    }

    private static void actualizarArchivoVentas() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(archivoVentas, false))) {
            for (Tiquete t : tiquetesVendidos) {
                bw.write(t.toRegistro());
                bw.newLine();
            }
        } catch (IOException e) {
            System.err.println("Error actualizando archivo de ventas.");
        }
    }

    public static List<Tiquete> getTiquetesVendidos() {
        return tiquetesVendidos;
    }
}

