package parque.ventas;

import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.data.*;
import parque.atraccion.*;
import java.io.*;
import java.time.LocalDateTime;
import java.util.*;
import java.time.LocalDate;
import parque.usuarios.*;

public class ValidadorTiquetes {
    private File logIntentos;  // Archivo donde se registran los intentos de validación

    // CONSTRUCTOR
    public ValidadorTiquetes(String rutaLog) {
        this.logIntentos = new File(rutaLog);
    }

    // VERIFICA SI UN TIQUETE ES VÁLIDO PARA LA ATRACCIÓN EN UNA FECHA
    public boolean esValidoPara(Tiquete tiquete, Atraccion atraccion, LocalDate fecha) {
        if (tiquete.isUsed()) return false;

        if (tiquete instanceof TiqueteIndividual) {
            TiqueteIndividual ti = (TiqueteIndividual) tiquete;
            return ti.getAtraccion().equals(atraccion);
        }

        if (tiquete instanceof TiqueteRegular) {
            TiqueteRegular tr = (TiqueteRegular) tiquete;

            if (tr instanceof TiqueteTemporada) {
                TiqueteTemporada temp = (TiqueteTemporada) tr;
                LocalDate inicio = temp.getRangoFechas().getInicio();
                LocalDate fin = temp.getRangoFechas().getFin();
                return fecha.isAfter(inicio.minusDays(1)) && fecha.isBefore(fin.plusDays(1));
            }

            return true;
        }

        return false;
    }

    public void registrarUso(Tiquete tiquete) {
        tiquete.setUsado();
    }

    public void logIntento(Tiquete tiquete, Atraccion atraccion, LocalDate fecha, boolean valido) {
        String estado = valido ? "VALIDO" : "INVALIDO";
        String mensaje = String.format("[%s] Se intentó usar el tiquete #%s en %s el %s. Estado: %s",
                LocalDate.now(), tiquete.getCodigo(), atraccion.getNombreAtraccion(), fecha, estado);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(logIntentos, true))) {
            bw.write(mensaje);
            bw.newLine();
        } catch (IOException e) {
            System.err.println("Error al escribir log de validación.");
        }
    }

    public String razonInvalidez(Tiquete tiquete, Atraccion atraccion, LocalDate fecha) {
        if (tiquete.isUsed()) return "Tiquete ya fue utilizado.";
        if (!esValidoPara(tiquete, atraccion, fecha)) return "El tiquete no aplica a esta atracción o en esta fecha.";
        return "Válido.";
    }
} 




