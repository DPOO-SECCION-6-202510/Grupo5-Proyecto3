package parque.enumeraciones;

//Vender, Cocinero, 
public enum Actividad{
	TRABAJO_ESPECIALIZADO, SERVICIO_GENERAL, CAJERO, COCINERO
}