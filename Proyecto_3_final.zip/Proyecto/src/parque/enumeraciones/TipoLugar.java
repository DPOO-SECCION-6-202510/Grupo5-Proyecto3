package parque.enumeraciones;

public enum TipoLugar{
	CAFETERIA, TIENDA, TAQUILLA
}