package parque.enumeraciones;

public enum RestriccionSalud {
	
	VERTIGO,
	PROBLEMAS_CARDIACOS,
	DISCAPACIDAD_FISICA

}
