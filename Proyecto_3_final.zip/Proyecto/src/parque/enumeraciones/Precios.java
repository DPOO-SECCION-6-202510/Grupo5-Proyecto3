package parque.enumeraciones;

public enum Precios{
	BASICO(15000),
	FAMILIAR(45000),
	ORO(75000),
	DIAMANTE(120000),
	INDIVIDUAL(10000),
	FASTPASS(20000);
	
	private final double precio;
	
	Precios(double precio){
		this.precio = precio;
	}
	
	public double getPrecio() {
		return precio;
	}
}