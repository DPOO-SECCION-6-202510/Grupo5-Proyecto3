package parque.enumeraciones;

public enum RestriccionClima {
	TORMENTA,
	FRIO_EXTREMO,
	CALOR_EXTREMO

}
