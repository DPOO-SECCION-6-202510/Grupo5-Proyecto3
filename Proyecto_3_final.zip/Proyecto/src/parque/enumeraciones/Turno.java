package parque.enumeraciones;

public enum Turno{
	APERTURA, CIERRE
}