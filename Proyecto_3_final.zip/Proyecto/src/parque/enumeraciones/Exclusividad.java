package parque.enumeraciones;

public enum Exclusividad {
	
	FAMILIAR,
	ORO,
	DIAMANTE,
	BASICO

}
