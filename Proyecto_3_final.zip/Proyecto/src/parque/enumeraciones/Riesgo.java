package parque.enumeraciones;

public enum Riesgo {
	MEDIO,
	ALTO
}
