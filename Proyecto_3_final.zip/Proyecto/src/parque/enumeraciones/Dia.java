package parque.enumeraciones;

public enum Dia{
	LUNES, MARTES, MIERCOLES, JUEVES, VIERNES, SABADO, DOMINGO
}