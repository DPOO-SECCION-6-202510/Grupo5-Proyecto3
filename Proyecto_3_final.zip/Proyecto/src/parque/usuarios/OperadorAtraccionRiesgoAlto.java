package parque.usuarios;

import java.util.ArrayList;
import java.util.List;

import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.data.*;
import parque.atraccion.*;
import java.time.LocalDate;

public class OperadorAtraccionRiesgoAlto extends Empleado{
    private AtraccionMecanica atraccionFija;

    public OperadorAtraccionRiesgoAlto(String usuario, String contraseña, String nombre, int edad, AtraccionMecanica atraccionFija) {
        super(usuario, contraseña, nombre, edad);
        this.atraccionFija = atraccionFija;
    }

    public AtraccionMecanica getAtraccionFija() {
        return atraccionFija;
    }

    public void setAtraccionFija(AtraccionMecanica atraccionFija) {
        this.atraccionFija = atraccionFija;
    }

    public String validarYRegistrarTiquete(Tiquete tiquete, LocalDate fecha, ValidadorTiquetes validador) {
        boolean valido = validador.esValidoPara(tiquete, atraccionFija, fecha);
        validador.logIntento(tiquete, atraccionFija, fecha, valido);

        if (valido) {
            validador.registrarUso(tiquete);
            return "Tiquete válido. Acceso concedido a " + atraccionFija.getNombreAtraccion();
        } else {
            return "Tiquete inválido: " + validador.razonInvalidez(tiquete, atraccionFija, fecha);
        }
    }
}

