package parque.usuarios;

import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.data.*;
import parque.atraccion.*;
import java.util.*;

public class Administrador extends Usuario {

    private ParqueAtracciones parque;

    public Administrador(String nombreUsuario, String login, String contrasena, ParqueAtracciones parque) {
        super(nombreUsuario, login,  contrasena, true, TipoUsuario.ADMINISTRADOR);
        this.parque = parque;
    }

    // -----------------------------
    // GESTIÓN DE EMPLEADOS
    // -----------------------------

    public void agregarEmpleado(Empleado e) {
        this.parque.getEmpleados().add(e);
    }

    public void eliminarEmpleado(Empleado e) {
        this.parque.getEmpleados().remove(e);
    }

    public void asignarLabor(Empleado e, Labor labor) {
        e.getLabores().add(labor);
    }

    public void quitarLabor(Empleado e, Labor labor) {
        e.getLabores().remove(labor);
    }

    // -----------------------------
    // GESTIÓN DE ATRACCIONES DEL PARQUE
    // -----------------------------

    public void agregarAtraccion(Atraccion atraccion) {
        this.parque.getAtracciones().add(atraccion);
    }

    public void eliminarAtraccion(Atraccion atraccion) {
        this.parque.getAtracciones().remove(atraccion);
    }

    // -----------------------------
    // GESTIÓN DE ATRACCIONES DE LOS OPERADORES
    // -----------------------------

    public void asignarAtraccionAOpeRiesgoMedio(OperadorAtraccionRiesgoMedio operador, AtraccionMecanica atraccion) {
        operador.getAtracciones().add(atraccion);
    }

    public void quitarAtraccionAOpeRiesgoMedio(OperadorAtraccionRiesgoMedio operador, AtraccionMecanica atraccion) {
        operador.getAtracciones().remove(atraccion);
    }

    public void asignarAtraccionAOpeRiesgoAlto(OperadorAtraccionRiesgoAlto operador, AtraccionMecanica atraccion) {
        operador.setAtraccionFija(atraccion);
    }

    public void quitarAtraccionAOpeRiesgoAlto(OperadorAtraccionRiesgoAlto operador) {
        operador.setAtraccionFija(null);
    }

    // -----------------------------
    // GESTIÓN DE ESPECTÁCULOS
    // -----------------------------

    public void agregarEspectaculo(Espectaculo espectaculo) {
        this.parque.getEspectaculos().add(espectaculo);
    }

    public void eliminarEspectaculo(Espectaculo espectaculo) {
        this.parque.getEspectaculos().remove(espectaculo);
    }

    // -----------------------------
    // Acceso a parque (solo lectura externa)
    // -----------------------------

    public ParqueAtracciones getParque() {
        return parque;
    }
}
