package parque.usuarios;

import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.data.*;
import parque.atraccion.*;
import parque.ventas.*;
import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Date;


public abstract class Empleado extends Usuario {
    protected String nombre;
    protected int edad;
    protected ArrayList<Labor> labores;

    public Empleado(String nombre, String login, String contraseña, int edad) {
        super(nombre, login, contraseña, true, TipoUsuario.EMPLEADO);
        this.nombre = nombre;
        this.edad = edad;
        this.labores = new ArrayList<Labor>();
    }

    public List<Labor> getLabores() {
        return labores;
    }

    public boolean tieneLaborDe(Actividad actividad) {
        for (Labor l : labores) {
            if (l.getTrabajo() == actividad) {
                return true;
            }
        }
        return false;
    }
    //Función como cajero. No se hace una clase a parte pues muchos empleados pueden ser cajeros. Agregar en Labores los trabajos
    public Tiquete venderTiqueteRegular(Usuario comprador, Exclusividad exclusividad, Precios precio) {
        if (!tieneLaborDe(Actividad.CAJERO)) {
            throw new IllegalStateException("Este empleado no tiene la labor de cajero.");
        }else {
        	return GestorVentas.venderTiqueteRegular(comprador, exclusividad, precio);
        }
       

    }
    
    public Tiquete venderTiqueteIndividual(Usuario comprador, String nombreAtraccion) {
    	double precio = Precios.INDIVIDUAL.getPrecio();
    	if (!tieneLaborDe(Actividad.CAJERO)) {
            throw new IllegalStateException("Este empleado no tiene la labor de cajero.");
        }else {
        	return GestorVentas.venderTiqueteIndividual(comprador, nombreAtraccion, precio);
        }
    	
    }
    
    public Tiquete venderTiqueteFastPass(Usuario comprador, Date fecha) {
    	double precio = Precios.FASTPASS.getPrecio();
    	if (!tieneLaborDe(Actividad.CAJERO)) {
            throw new IllegalStateException("Este empleado no tiene la labor de cajero.");
        }else {
        	return GestorVentas.venderFastPass(comprador, fecha , precio);
        }
    }
    
    public Tiquete venderTiqueteTemporada(Usuario comprador, Precios precio, LocalDate fechaInicio, LocalDate fechaFinal) {
    	RangoFuncionamiento rango = new RangoFuncionamiento(fechaInicio, fechaFinal);
        if (!tieneLaborDe(Actividad.CAJERO)) {
            throw new IllegalStateException("Este empleado no tiene la labor de cajero.");
        }else if (precio == Precios.BASICO) {
        	return GestorVentas.venderTiqueteTemporada(comprador, Exclusividad.BASICO, rango, precio);
        }else if (precio == Precios.FAMILIAR) {
        	return GestorVentas.venderTiqueteTemporada(comprador, Exclusividad.FAMILIAR, rango, precio);
        }else if (precio == Precios.ORO) {
        	return GestorVentas.venderTiqueteTemporada(comprador, Exclusividad.ORO,rango, precio);
        }else {
        	return GestorVentas.venderTiqueteTemporada(comprador, Exclusividad.DIAMANTE,rango, precio);
        }
    }
    
}
