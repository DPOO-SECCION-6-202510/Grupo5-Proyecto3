package parque.usuarios;

import java.util.ArrayList;
import java.util.List;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.data.*;
import parque.atraccion.*;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
public class OperadorAtraccionRiesgoMedio extends Empleado {
    private List<AtraccionMecanica> atracciones;

    public OperadorAtraccionRiesgoMedio(String usuario, String contraseña, String nombre, int edad) {
        super(usuario, contraseña, nombre, edad);
        this.atracciones = new ArrayList<>();
    }

    public List<AtraccionMecanica> getAtracciones() {
        return atracciones;
    }

    public void setAtracciones(List<AtraccionMecanica> atracciones) {
        this.atracciones = atracciones;
    }

    public String validarYRegistrarTiquete(Tiquete tiquete, Atraccion atraccion, LocalDate fecha, ValidadorTiquetes validador) {
        boolean valido = validador.esValidoPara(tiquete, atraccion, fecha);
        validador.logIntento( tiquete, atraccion, fecha, valido);

        if (valido) {
            validador.registrarUso(tiquete);
            return "Tiquete válido. Acceso concedido.";
        } else {
            return "Tiquete inválido: " + validador.razonInvalidez(tiquete, atraccion, fecha);
        }
    }
}

