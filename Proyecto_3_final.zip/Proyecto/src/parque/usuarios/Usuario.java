package parque.usuarios;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.data.*;
import parque.atraccion.*;

public abstract class Usuario {
	private String nombre;
    private String login;
    private String password;
    private ArrayList<Tiquete> tiquetesIndividuales;
    private ArrayList<Tiquete> tiquetesRegulares;
    private ArrayList<Tiquete> tiquetesTemporada;
    private ArrayList<Tiquete> tiquetesFastPass;
    private Boolean esEmpleado;
    private int edad;
    private double peso;
    private TipoUsuario tipo;
    
    public enum TipoUsuario {
        CLIENTE, EMPLEADO, ADMINISTRADOR
    }
    
    //Tanto clientes, como empleados y administradores pueden comprar tiquetes.
    public Usuario(String nombre, String login, String password, Boolean esEmpleado, TipoUsuario tipo) {
        this.nombre = nombre;
        this.login = login;
        this.password = password;
        this.tiquetesIndividuales = new ArrayList<Tiquete>();
        this.tiquetesRegulares = new ArrayList<Tiquete>();
        this.tiquetesTemporada = new ArrayList<Tiquete>();
        this.tiquetesFastPass = new ArrayList<Tiquete>();
        this.esEmpleado = esEmpleado;
        this.tipo = tipo;
    }
    
    //Queremos Implementar las compras en Linea. El gestor de compras se encargará de validar y usará este método cuando sea necesario
    public void agregarTiquete(Tiquete tiquete) {
        if (tiquete instanceof TiqueteIndividual) {
            tiquetesIndividuales.add(tiquete);
        } else if (tiquete instanceof TiqueteRegular) {
            tiquetesRegulares.add(tiquete);
        } else if (tiquete instanceof FastPass) {
            tiquetesFastPass.add(tiquete);
        }
    }
    
    //Queremos que el cliente pueda consultar el catálogo. Llamamos a la clase ParqueAtracciones que tiene toda la información.
    public void consultarCatalogo(ParqueAtracciones parque, String rutaArchivo) {
        parque.mostrarCatalogo(rutaArchivo);
    }
    
    

    // Getters y Setters
    public TipoUsuario getTipoUsuario() {
    	return this.tipo;
    }
    
    public int getEdad() { return this.edad; }
    public void setEdad(int edad) { this.edad = edad; }
    
    public double getPeso() { return this.peso; }
    public void setPeso(double peso) { this.peso = peso; }
    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getLogin() { return login; }
    public void setLogin(String login) { this.login = login; }

    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    
    public Boolean esEmpleado() {return esEmpleado;}

    public ArrayList<Tiquete> getTiquetesIndividuales() { return tiquetesIndividuales; }
    public ArrayList<Tiquete> getTiquetesRegulares() { return tiquetesRegulares; }
    public ArrayList<Tiquete> getTiquetesFastPass() { return tiquetesFastPass; }
    public ArrayList<Tiquete> getTiquetesTemporada() { return tiquetesTemporada; }
    
    public Tiquete comprarTiqueteRegularEnLinea(Exclusividad categoria, Precios precio) {
        return GestorVentas.venderTiqueteRegular(this, categoria, precio);
    }

    public Tiquete comprarTiqueteIndividualEnLinea(String nombreAtraccion, double precioBase) {
        return GestorVentas.venderTiqueteIndividual(this, nombreAtraccion, precioBase);
    }

    public Tiquete comprarTiqueteTemporadaEnLinea(Exclusividad categoria, RangoFuncionamiento rango, Precios precio) {
        return GestorVentas.venderTiqueteTemporada(this, categoria, rango, precio);
    }

    public Tiquete comprarFastPassEnLinea(Date fecha, double precioBase) {
        return GestorVentas.venderFastPass(this, fecha, precioBase);
    }
}