package parque.modelo;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;
import parque.atraccion.*;
import java.time.LocalDate;

public class RangoFuncionamiento {
	
	private LocalDate fechaInicio;
	private LocalDate fechaFin;
	
	
	public RangoFuncionamiento(LocalDate inicio, LocalDate fin) {
		this.fechaInicio = inicio;
		this.fechaFin = fin;
	}
	
	
	public LocalDate getInicio() {
		return fechaInicio;
	}
	
	public LocalDate getFin() {
		return fechaFin;
	}

}
