package parque.modelo;

import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;
import parque.atraccion.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;


public class Espectaculo {
	
	private String nombre;
	private Ubicacion ubicacion;
	private LocalTime horaInicio;
	private LocalTime horaFin;
	private LocalDate fecha;
	private boolean esDeTemporada;
	private RangoFuncionamiento rangoTiempoFuncionamiento;
	private List<RestriccionClima> restriccionesPorClima = new ArrayList<RestriccionClima>();
	
	
	
	public Espectaculo(String nombre, Ubicacion ubicacion, LocalTime inicio, LocalTime fin, LocalDate fecha, boolean deTemporada, RangoFuncionamiento rango, List<RestriccionClima> restriccionesClima) {
		this.nombre = nombre;
		this.ubicacion = ubicacion;
		this.horaInicio = inicio;
		this.horaFin = fin;
		this.fecha = fecha;
		this.esDeTemporada = deTemporada;
		this.rangoTiempoFuncionamiento = rango;
		this.restriccionesPorClima = restriccionesClima;
	}
	
	
	public String getNombre() {
		return nombre;
	}
	
	public Ubicacion getUbicacion() {
		return ubicacion;
	}
	
	public LocalTime getHoraInicio() {
		return horaInicio;
	}
	
	public LocalTime getHoraFin() {
		return horaFin;
	}
	
	public LocalDate getFecha() {
		return fecha;
	}
	
	public boolean isDeTemporada() {
		return esDeTemporada;
	}
	
	public RangoFuncionamiento getRangoTiempo() {
		return rangoTiempoFuncionamiento;
	}
	
	public List<RestriccionClima> getRestriccionesClima(){
		return restriccionesPorClima;
	}
	
	

}
