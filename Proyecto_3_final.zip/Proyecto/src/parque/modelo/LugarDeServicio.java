package parque.modelo;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;
import parque.atraccion.*;

public class LugarDeServicio implements LugarDeTrabajo{
    private String nombre;
    private Ubicacion ubicacion;
    private TipoLugar tipo;

    public LugarDeServicio(String nombre, Ubicacion ubicacion, TipoLugar tipo) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.tipo = tipo;
    }

    public String getNombre() {
        return nombre;
    }

    public Ubicacion getUbicacion() {
        return ubicacion;
    }

    public TipoLugar getTipo() {
        return tipo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setUbicacion(Ubicacion ubicacion) {
        this.ubicacion = ubicacion;
    }

    public void setTipo(TipoLugar tipo) {
        this.tipo = tipo;
    }
}
