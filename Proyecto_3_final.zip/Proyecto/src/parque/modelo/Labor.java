package parque.modelo;

import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;
import parque.atraccion.*;
import java.time.LocalDate;

public class Labor {
	//Queremos que el Administrador sea capaz de modificar las labores, pero que los empleados mismos no puedan modificarlos, solo usar los getters
	//para ver la informacion.
	public LocalDate fecha;
	public Turno turno;
	public LugarDeTrabajo lugar;
	public Actividad trabajo;
	
	public Labor(Dia diaDeLaSemana, Turno turno, Actividad trabajo, LugarDeTrabajo lugarDeTrabajo, LocalDate fecha) {
        this.turno = turno;
        this.trabajo = trabajo;
        this.lugar = lugarDeTrabajo;
        this.fecha = fecha;
    }
	
	public Actividad getTrabajo() {
		return this.trabajo;
	};
	
	public LugarDeTrabajo getLugarDeTrabajo() {
		return this.lugar;
	};
	
	public Turno getTurno() {
		return this.turno;
	};
	
	public LocalDate getFecha() {
		return this.fecha;
	}
	
}
