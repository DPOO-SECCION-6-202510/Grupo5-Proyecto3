package parque.modelo;
import parque.enumeraciones.*;

public class LugarDeServicios implements LugarDeTrabajo {
	
	private String nombre;
	private Ubicacion ubicacion;
	private TipoLugar tipo;

	public LugarDeServicios(String nombre, Ubicacion ubicacion, TipoLugar tipo) {
		this.nombre = nombre;
		this.ubicacion = ubicacion;
		this.tipo = tipo;
	}

	public String getNombre() {
		return this.nombre;
	}
	
	public Ubicacion getUbicacion() {
		return this.ubicacion;
	}
	
	public TipoLugar getTipoLugar() {
		return this.tipo;
	}
}
