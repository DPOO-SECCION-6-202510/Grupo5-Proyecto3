package parque.modelo;
import parque.enumeraciones.*;
import parque.tiquetes.*;
import parque.ventas.*;
import parque.modelo.*;
import parque.usuarios.*;
import parque.data.*;
import parque.atraccion.*;

public class Ubicacion {
	
	private String areaTematica;
	private int cuadrante;
	private String direccion;
	
	
	public Ubicacion(String area, int cuad, String dir) {
		this.areaTematica = area;
		this.cuadrante = cuad;
		this.direccion = dir;
	}
	
	
	public String getAreaTematica() {
		return areaTematica;
	}
	
	public int getCuadrante() {
		return cuadrante;
	}
	
	public String getDireccion() {
		return direccion;
	}

}
